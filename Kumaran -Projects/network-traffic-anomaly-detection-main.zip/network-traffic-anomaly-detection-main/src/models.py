"""
Anomaly detection models.

We compare three unsupervised detectors from scikit-learn:
  - Isolation Forest
  - One-Class SVM
  - Local Outlier Factor (LOF)

All of them follow the scikit-learn convention:
  prediction =  1  -> normal
  prediction = -1  -> anomaly
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.svm import OneClassSVM
from sklearn.neighbors import LocalOutlierFactor
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)


def _normalise_scores(scores: np.ndarray) -> np.ndarray:
    """Scale raw anomaly scores to 0..1 where higher == more anomalous."""
    scores = np.asarray(scores, dtype=float)
    # Invert: in sklearn higher decision_function = more normal
    inverted = -scores
    lo, hi = inverted.min(), inverted.max()
    if hi - lo == 0:
        return np.zeros_like(inverted)
    return (inverted - lo) / (hi - lo)


def run_isolation_forest(X: pd.DataFrame, contamination: float):
    model = IsolationForest(
        n_estimators=200,
        contamination=contamination,
        random_state=42,
    )
    preds = model.fit_predict(X.values)
    scores = _normalise_scores(model.decision_function(X.values))
    return preds, scores


def run_one_class_svm(X: pd.DataFrame, contamination: float):
    model = OneClassSVM(kernel="rbf", gamma="scale", nu=max(min(contamination, 0.5), 1e-3))
    preds = model.fit_predict(X.values)
    scores = _normalise_scores(model.decision_function(X.values))
    return preds, scores


def run_lof(X: pd.DataFrame, contamination: float):
    n_neighbors = min(20, max(5, len(X) - 1))
    model = LocalOutlierFactor(n_neighbors=n_neighbors, contamination=contamination)
    preds = model.fit_predict(X.values)
    scores = _normalise_scores(model.negative_outlier_factor_)
    return preds, scores


MODEL_REGISTRY = {
    "Isolation Forest": run_isolation_forest,
    "One-Class SVM": run_one_class_svm,
    "Local Outlier Factor": run_lof,
}


def run_all_models(X: pd.DataFrame, contamination: float, selected: list[str]) -> dict:
    """
    Run the selected models and return a results dict:
      {
        model_name: {
          "pred": np.ndarray (1 / -1),
          "score": np.ndarray (0..1, higher = more anomalous),
          "anomalies": int,
        }
      }
    """
    results = {}
    for name in selected:
        runner = MODEL_REGISTRY[name]
        preds, scores = runner(X, contamination)
        results[name] = {
            "pred": preds,
            "score": scores,
            "anomalies": int((preds == -1).sum()),
        }
    return results


def ensemble_vote(results: dict, n_rows: int) -> np.ndarray:
    """
    Majority vote across models. A packet is flagged anomalous (-1) if at
    least half of the selected models flag it.
    """
    if not results:
        return np.ones(n_rows, dtype=int)

    votes = np.zeros(n_rows, dtype=int)
    for r in results.values():
        votes += (r["pred"] == -1).astype(int)

    threshold = len(results) / 2.0
    return np.where(votes >= threshold, -1, 1)


# ==========================================================================
# Evaluation against ground-truth labels (when the capture is labeled)
# ==========================================================================
def _binary_metrics(y_true: np.ndarray, y_pred: np.ndarray, scores: np.ndarray | None = None) -> dict:
    """Compute the standard set of binary-classification metrics."""
    metrics = {
        "Accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
        "Precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 4),
        "Recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 4),
        "F1-score": round(float(f1_score(y_true, y_pred, zero_division=0)), 4),
    }
    if scores is not None and len(np.unique(y_true)) > 1:
        try:
            metrics["ROC-AUC"] = round(float(roc_auc_score(y_true, scores)), 4)
        except ValueError:
            metrics["ROC-AUC"] = float("nan")
    return metrics


def evaluate_unsupervised(results: dict, ensemble: np.ndarray, y_true) -> pd.DataFrame:
    """
    Compare each unsupervised model (and the ensemble) against the ground-truth
    labels. Returns a metrics table (one row per model).

    Convention: anomaly = 1, normal = 0. Model preds use -1 for anomaly.
    """
    y_true = np.asarray(y_true).astype(int)
    rows = []
    for name, r in results.items():
        y_pred = (r["pred"] == -1).astype(int)
        rows.append({"Model": name, **_binary_metrics(y_true, y_pred, r["score"])})

    ens_pred = (ensemble == -1).astype(int)
    rows.append({"Model": "Ensemble (majority vote)", **_binary_metrics(y_true, ens_pred)})
    return pd.DataFrame(rows)


def confusion_for(pred: np.ndarray, y_true) -> np.ndarray:
    """Return a 2x2 confusion matrix [[TN, FP], [FN, TP]] for anomaly=1."""
    y_true = np.asarray(y_true).astype(int)
    y_pred = (np.asarray(pred) == -1).astype(int)
    return confusion_matrix(y_true, y_pred, labels=[0, 1])


# ==========================================================================
# Supervised model: Random Forest (needs labeled data)
# ==========================================================================
def train_supervised_rf(X: pd.DataFrame, y, test_size: float = 0.3) -> dict:
    """
    Train a Random Forest classifier on labeled traffic and evaluate it on a
    held-out test split.

    Returns a dict with metrics, confusion matrix, ROC curve data and the
    most important features.
    """
    y = np.asarray(y).astype(int)

    stratify = y if len(np.unique(y)) > 1 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X.values, y, test_size=test_size, random_state=42, stratify=stratify
    )

    clf = RandomForestClassifier(
        n_estimators=300, random_state=42, class_weight="balanced", n_jobs=-1
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    proba = clf.predict_proba(X_test)
    # Probability of the positive (anomaly) class
    pos_idx = list(clf.classes_).index(1) if 1 in clf.classes_ else -1
    pos_proba = proba[:, pos_idx] if pos_idx >= 0 else np.zeros(len(y_test))

    metrics = _binary_metrics(y_test, y_pred, pos_proba)
    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

    roc = None
    if len(np.unique(y_test)) > 1:
        fpr, tpr, _ = roc_curve(y_test, pos_proba)
        roc = {"fpr": fpr, "tpr": tpr}

    importances = (
        pd.DataFrame(
            {"feature": X.columns, "importance": clf.feature_importances_}
        )
        .sort_values("importance", ascending=False)
        .reset_index(drop=True)
    )

    return {
        "metrics": metrics,
        "confusion": cm,
        "roc": roc,
        "importances": importances,
        "n_train": len(y_train),
        "n_test": len(y_test),
    }
