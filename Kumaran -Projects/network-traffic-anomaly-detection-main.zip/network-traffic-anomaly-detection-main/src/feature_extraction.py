"""
Feature extraction module.

Reads network traffic from either:
  1. A Wireshark CSV export (File -> Export Packet Dissections -> As CSV)
  2. A raw .pcap / .pcapng capture file (parsed with scapy)

It normalises the data into a common per-packet DataFrame and then builds
a numeric feature matrix that the ML models can consume.
"""

from __future__ import annotations

import io
import pandas as pd
import numpy as np


# Common Wireshark column aliases -> normalised name
_COLUMN_ALIASES = {
    "no.": "no",
    "no": "no",
    "time": "time",
    "source": "src",
    "src": "src",
    "ip.src": "src",
    "destination": "dst",
    "dst": "dst",
    "ip.dst": "dst",
    "protocol": "protocol",
    "ip.proto": "protocol",
    "length": "length",
    "frame.len": "length",
    "len": "length",
    "info": "info",
    "tcp.srcport": "src_port",
    "udp.srcport": "src_port",
    "tcp.dstport": "dst_port",
    "udp.dstport": "dst_port",
    "label": "label",
    "class": "label",
    "attack": "label",
    "target": "label",
}


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename columns to a canonical set based on known aliases."""
    rename_map = {}
    for col in df.columns:
        key = str(col).strip().lower()
        if key in _COLUMN_ALIASES:
            rename_map[col] = _COLUMN_ALIASES[key]
    df = df.rename(columns=rename_map)
    # Drop duplicate columns that may appear after renaming
    df = df.loc[:, ~df.columns.duplicated()]
    return df


def load_csv(file) -> pd.DataFrame:
    """Load a Wireshark CSV export into a normalised per-packet DataFrame."""
    raw = pd.read_csv(file)
    df = _normalise_columns(raw)

    # Ensure the core columns exist
    for needed in ["time", "src", "dst", "protocol", "length"]:
        if needed not in df.columns:
            df[needed] = np.nan

    df["length"] = pd.to_numeric(df["length"], errors="coerce")
    df["time"] = pd.to_numeric(df["time"], errors="coerce")

    if "src_port" not in df.columns:
        df["src_port"] = np.nan
    if "dst_port" not in df.columns:
        df["dst_port"] = np.nan

    return df


def load_pcap(file_bytes: bytes) -> pd.DataFrame:
    """Parse a raw pcap/pcapng file (as bytes) into a normalised DataFrame."""
    from scapy.all import rdpcap, IP, TCP, UDP, ICMP  # imported lazily

    packets = rdpcap(io.BytesIO(file_bytes))
    rows = []
    base_time = None

    for pkt in packets:
        ts = float(pkt.time)
        if base_time is None:
            base_time = ts

        src = dst = None
        protocol = pkt.lastlayer().name if hasattr(pkt, "lastlayer") else "OTHER"
        src_port = dst_port = np.nan

        if IP in pkt:
            src = pkt[IP].src
            dst = pkt[IP].dst
            if TCP in pkt:
                protocol = "TCP"
                src_port = int(pkt[TCP].sport)
                dst_port = int(pkt[TCP].dport)
            elif UDP in pkt:
                protocol = "UDP"
                src_port = int(pkt[UDP].sport)
                dst_port = int(pkt[UDP].dport)
            elif ICMP in pkt:
                protocol = "ICMP"

        rows.append(
            {
                "time": ts - base_time,
                "src": src,
                "dst": dst,
                "protocol": protocol,
                "length": len(pkt),
                "src_port": src_port,
                "dst_port": dst_port,
            }
        )

    return pd.DataFrame(rows)


def extract_labels(df: pd.DataFrame) -> pd.Series | None:
    """
    Return a binary ground-truth label Series (1 = anomaly, 0 = normal) if a
    label column exists, otherwise None.

    Accepts numeric labels (0/1) or text labels such as
    "normal"/"anomaly"/"attack"/"malicious".
    """
    if "label" not in df.columns:
        return None

    raw = df["label"]
    # Numeric labels: anything > 0 (or != 0) is an anomaly
    numeric = pd.to_numeric(raw, errors="coerce")
    if numeric.notna().mean() > 0.8:
        return (numeric.fillna(0) != 0).astype(int)

    # Text labels
    normal_words = {"normal", "benign", "ok", "good", "0", "none", "no"}
    text = raw.astype(str).str.strip().str.lower()
    return (~text.isin(normal_words)).astype(int)


def build_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build a numeric feature matrix from the normalised packet DataFrame.

    Returns:
        features  -> numeric DataFrame used for modelling
        enriched  -> original df + a few engineered columns (for display)
    """
    df = df.copy().reset_index(drop=True)

    # --- Basic numeric features ---
    df["length"] = pd.to_numeric(df["length"], errors="coerce").fillna(0)
    df["time"] = pd.to_numeric(df["time"], errors="coerce")
    if df["time"].isna().all():
        df["time"] = np.arange(len(df), dtype=float)
    df["time"] = df["time"].ffill().fillna(0)

    df["src_port"] = pd.to_numeric(df.get("src_port"), errors="coerce").fillna(0)
    df["dst_port"] = pd.to_numeric(df.get("dst_port"), errors="coerce").fillna(0)

    # --- Inter-arrival time between consecutive packets ---
    df["inter_arrival"] = df["time"].diff().fillna(0).clip(lower=0)

    # --- Protocol one-hot (top protocols) ---
    proto = df["protocol"].astype(str).str.upper().fillna("OTHER")
    df["is_tcp"] = (proto == "TCP").astype(int)
    df["is_udp"] = (proto == "UDP").astype(int)
    df["is_icmp"] = (proto == "ICMP").astype(int)

    # --- Per-source flow aggregates (helps catch scans / floods) ---
    if df["src"].notna().any():
        src_counts = df.groupby("src")["length"].transform("count")
        src_bytes = df.groupby("src")["length"].transform("sum")
    else:
        src_counts = pd.Series(1, index=df.index)
        src_bytes = df["length"]
    df["src_pkt_count"] = src_counts
    df["src_total_bytes"] = src_bytes

    # --- Per-destination unique-port count (helps catch port scans) ---
    if df["dst"].notna().any():
        df["dst_unique_ports"] = df.groupby("dst")["dst_port"].transform("nunique")
    else:
        df["dst_unique_ports"] = 1

    feature_cols = [
        "length",
        "inter_arrival",
        "src_port",
        "dst_port",
        "is_tcp",
        "is_udp",
        "is_icmp",
        "src_pkt_count",
        "src_total_bytes",
        "dst_unique_ports",
    ]

    features = df[feature_cols].replace([np.inf, -np.inf], 0).fillna(0)
    return features, df
