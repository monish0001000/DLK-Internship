"""
Preprocessing module: scaling of the numeric feature matrix.

Anomaly detectors (especially One-Class SVM and LOF) are distance based,
so feature scaling with StandardScaler is essential.
"""

from __future__ import annotations

import pandas as pd
from sklearn.preprocessing import StandardScaler


def scale_features(features: pd.DataFrame) -> tuple[pd.DataFrame, StandardScaler]:
    """Standardise features to zero mean and unit variance."""
    scaler = StandardScaler()
    scaled = scaler.fit_transform(features.values)
    scaled_df = pd.DataFrame(scaled, columns=features.columns, index=features.index)
    return scaled_df, scaler
