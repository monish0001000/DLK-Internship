"""
Network Traffic Anomaly Detection - Streamlit Dashboard
=======================================================

Workflow:
  1. Upload a Wireshark CSV export or a raw .pcap/.pcapng file
  2. Features are extracted & scaled
  3. Multiple unsupervised models (Isolation Forest, One-Class SVM, LOF)
     are run and compared
  4. An ensemble majority vote highlights the most suspicious packets
  5. Results can be explored visually and downloaded as CSV
"""

from __future__ import annotations

import io
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src.feature_extraction import load_csv, load_pcap, build_features, extract_labels
from src.preprocessing import scale_features
from src.models import (
    run_all_models,
    ensemble_vote,
    evaluate_unsupervised,
    train_supervised_rf,
    MODEL_REGISTRY,
)

# --------------------------------------------------------------------------
# Page config & light styling
# --------------------------------------------------------------------------
st.set_page_config(
    page_title="Network Traffic Anomaly Detection",
    page_icon="🛡️",
    layout="wide",
)

st.markdown(
    """
    <style>
      .block-container {padding-top: 2rem; max-width: 1300px;}
      div[data-testid="stMetric"] {
          background: #131c2e; border: 1px solid #22304a;
          border-radius: 12px; padding: 16px 18px;
      }
      h1, h2, h3 {letter-spacing: -0.01em;}
    </style>
    """,
    unsafe_allow_html=True,
)

ACCENT = "#22d3ee"
DANGER = "#f87171"


# --------------------------------------------------------------------------
# Sidebar - controls
# --------------------------------------------------------------------------
with st.sidebar:
    st.title("🛡️ Anomaly Detector")
    st.caption("Wireshark + scikit-learn")

    st.subheader("1. Upload capture")
    uploaded = st.file_uploader(
        "Wireshark CSV export or .pcap / .pcapng",
        type=["csv", "pcap", "pcapng"],
    )
    use_sample = st.checkbox("Use bundled sample data", value=not uploaded)

    st.subheader("2. Models")
    selected_models = st.multiselect(
        "Compare these detectors",
        options=list(MODEL_REGISTRY.keys()),
        default=list(MODEL_REGISTRY.keys()),
    )

    st.subheader("3. Sensitivity")
    contamination = st.slider(
        "Expected anomaly fraction (contamination)",
        min_value=0.01, max_value=0.30, value=0.08, step=0.01,
        help="Roughly what proportion of traffic you expect to be anomalous.",
    )

    run_btn = st.button("Run detection", type="primary", use_container_width=True)


# --------------------------------------------------------------------------
# Data loading
# --------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def _load_dataframe(file_bytes: bytes | None, name: str | None, sample: bool) -> pd.DataFrame:
    if sample or file_bytes is None:
        return load_csv("sample_data/sample_traffic.csv")
    if name and name.lower().endswith((".pcap", ".pcapng")):
        return load_pcap(file_bytes)
    return load_csv(io.BytesIO(file_bytes))


st.title("Network Traffic Anomaly Detection")
st.write(
    "Upload captured network traffic and let unsupervised machine-learning "
    "models flag suspicious packets — port scans, floods, and unusual data transfers."
)

# Resolve the input source
file_bytes = uploaded.getvalue() if uploaded else None
file_name = uploaded.name if uploaded else None
sample_mode = use_sample or file_bytes is None

try:
    df = _load_dataframe(file_bytes, file_name, sample_mode)
except Exception as exc:  # noqa: BLE001
    st.error(f"Could not read the file: {exc}")
    st.stop()

if df.empty:
    st.warning("The capture contains no packets.")
    st.stop()

source_label = "bundled sample" if sample_mode else file_name
st.success(f"Loaded **{len(df):,} packets** from *{source_label}*.")


# --------------------------------------------------------------------------
# Tabs
# --------------------------------------------------------------------------
tab_overview, tab_features, tab_results, tab_explore, tab_eval = st.tabs(
    ["Overview", "Features", "Model comparison", "Explore anomalies",
     "Supervised & Metrics"]
)

# Build features once (used across tabs)
features, enriched = build_features(df)
labels = extract_labels(df)  # ground-truth labels if the capture has a label column

if labels is not None:
    st.info(
        f"Ground-truth labels detected: **{int(labels.sum()):,} anomalies** / "
        f"**{int((labels == 0).sum()):,} normal** packets. "
        "Supervised model and accuracy metrics are available in the last tab."
    )

# ---- Overview tab --------------------------------------------------------
with tab_overview:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total packets", f"{len(df):,}")
    c2.metric("Unique sources", f"{df['src'].nunique():,}")
    c3.metric("Unique destinations", f"{df['dst'].nunique():,}")
    c4.metric("Avg packet size", f"{features['length'].mean():.0f} B")

    left, right = st.columns(2)
    with left:
        proto_counts = (
            df["protocol"].astype(str).str.upper().value_counts().reset_index()
        )
        proto_counts.columns = ["protocol", "count"]
        fig = px.bar(
            proto_counts.head(8), x="protocol", y="count",
            title="Protocol distribution", color_discrete_sequence=[ACCENT],
        )
        fig.update_layout(template="plotly_dark", height=340, margin=dict(t=50, b=10))
        st.plotly_chart(fig, use_container_width=True)
    with right:
        fig = px.histogram(
            features, x="length", nbins=40,
            title="Packet size distribution", color_discrete_sequence=[ACCENT],
        )
        fig.update_layout(template="plotly_dark", height=340, margin=dict(t=50, b=10))
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Raw packets (first 200 rows)")
    st.dataframe(df.head(200), use_container_width=True, height=300)

# ---- Features tab --------------------------------------------------------
with tab_features:
    st.subheader("Engineered numeric features")
    st.write(
        "Each packet is converted into the numeric features below. "
        "These are standardised (zero mean, unit variance) before modelling."
    )
    st.dataframe(features.head(200), use_container_width=True, height=320)

    st.subheader("Feature correlation")
    corr = features.corr().round(2)
    fig = px.imshow(
        corr, text_auto=True, aspect="auto",
        color_continuous_scale="Tealgrn", title="Correlation matrix",
    )
    fig.update_layout(template="plotly_dark", height=480, margin=dict(t=50))
    st.plotly_chart(fig, use_container_width=True)

# ---- Model comparison tab ------------------------------------------------
with tab_results:
    if not run_btn and "results" not in st.session_state:
        st.info("Set your options in the sidebar and click **Run detection**.")
    if run_btn:
        if not selected_models:
            st.error("Select at least one model in the sidebar.")
            st.stop()
        with st.spinner("Scaling features and running models..."):
            X, _ = scale_features(features)
            results = run_all_models(X, contamination, selected_models)
            ens = ensemble_vote(results, len(X))
            st.session_state["results"] = results
            st.session_state["ensemble"] = ens
            st.session_state["enriched"] = enriched
            st.session_state["features"] = features
            st.session_state["labels"] = labels
            st.session_state["scaled_X"] = X

    if "results" in st.session_state:
        results = st.session_state["results"]
        ens = st.session_state["ensemble"]

        st.subheader("Anomalies detected per model")
        summary = pd.DataFrame(
            [
                {
                    "Model": name,
                    "Anomalies": r["anomalies"],
                    "Anomaly %": round(100 * r["anomalies"] / len(ens), 2),
                }
                for name, r in results.items()
            ]
        )
        ens_count = int((ens == -1).sum())
        summary.loc[len(summary)] = [
            "Ensemble (majority vote)", ens_count,
            round(100 * ens_count / len(ens), 2),
        ]

        col1, col2 = st.columns([1, 1])
        with col1:
            st.dataframe(summary, use_container_width=True, hide_index=True)
        with col2:
            fig = px.bar(
                summary, x="Model", y="Anomalies",
                color="Model", title="Detected anomalies by model",
            )
            fig.update_layout(template="plotly_dark", height=340,
                              showlegend=False, margin=dict(t=50))
            st.plotly_chart(fig, use_container_width=True)

        st.subheader("Model agreement (anomaly scores)")
        score_df = pd.DataFrame({name: r["score"] for name, r in results.items()})
        if score_df.shape[1] >= 2:
            cols = list(score_df.columns)
            fig = px.scatter(
                score_df, x=cols[0], y=cols[1],
                color=(ens == -1),
                color_discrete_map={True: DANGER, False: ACCENT},
                labels={"color": "Anomaly"},
                title=f"{cols[0]} vs {cols[1]} anomaly score",
            )
            fig.update_layout(template="plotly_dark", height=420, margin=dict(t=50))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.bar_chart(score_df)

# ---- Explore anomalies tab ----------------------------------------------
with tab_explore:
    if "results" not in st.session_state:
        st.info("Run detection first to explore flagged packets.")
    else:
        enriched = st.session_state["enriched"].copy()
        ens = st.session_state["ensemble"]
        results = st.session_state["results"]

        enriched["anomaly"] = ens == -1
        # Average anomaly score across models for ranking
        score_matrix = pd.DataFrame({n: r["score"] for n, r in results.items()})
        enriched["anomaly_score"] = score_matrix.mean(axis=1).values

        n_anom = int(enriched["anomaly"].sum())
        st.metric("Packets flagged by ensemble", f"{n_anom:,}")

        st.subheader("Traffic timeline (anomalies in red)")
        fig = go.Figure()
        normal = enriched[~enriched["anomaly"]]
        anom = enriched[enriched["anomaly"]]
        fig.add_trace(go.Scatter(
            x=normal["time"], y=normal["length"], mode="markers",
            name="Normal", marker=dict(color=ACCENT, size=5, opacity=0.5),
        ))
        fig.add_trace(go.Scatter(
            x=anom["time"], y=anom["length"], mode="markers",
            name="Anomaly", marker=dict(color=DANGER, size=9, symbol="x"),
        ))
        fig.update_layout(
            template="plotly_dark", height=420,
            xaxis_title="Time (s)", yaxis_title="Packet length (bytes)",
            margin=dict(t=30),
        )
        st.plotly_chart(fig, use_container_width=True)

        st.subheader("Flagged packets (sorted by anomaly score)")
        show_cols = [c for c in
                     ["time", "src", "dst", "protocol", "length",
                      "src_port", "dst_port", "anomaly_score"]
                     if c in enriched.columns]
        flagged = (
            enriched[enriched["anomaly"]]
            .sort_values("anomaly_score", ascending=False)[show_cols]
        )
        st.dataframe(flagged, use_container_width=True, height=320)

        csv_out = enriched[show_cols + ["anomaly"]].to_csv(index=False).encode()
        st.download_button(
            "⬇️ Download full results (CSV)",
            data=csv_out, file_name="anomaly_results.csv",
            mime="text/csv", type="primary",
        )

# ---- Supervised & Metrics tab -------------------------------------------
def _confusion_heatmap(cm, title: str):
    """Render a 2x2 confusion matrix as a labelled heatmap."""
    fig = px.imshow(
        cm,
        text_auto=True,
        color_continuous_scale="Tealgrn",
        x=["Pred normal", "Pred anomaly"],
        y=["True normal", "True anomaly"],
        title=title,
    )
    fig.update_layout(template="plotly_dark", height=360, margin=dict(t=50))
    return fig


with tab_eval:
    st.subheader("Accuracy metrics & supervised classifier")
    st.caption(
        "These features require a labeled capture. Add a `Label` column "
        "(0 = normal, 1 = anomaly — text like 'normal'/'attack' also works) "
        "to your CSV. The bundled sample data is already labeled."
    )

    if labels is None:
        st.warning(
            "No `Label` column found in this capture, so ground-truth "
            "metrics and the supervised model can't be computed. "
            "Use the bundled sample data or add a label column to your export."
        )
    elif "results" not in st.session_state:
        st.info("Run detection from the sidebar first to score the unsupervised models.")
    else:
        y_true = st.session_state["labels"]
        results = st.session_state["results"]
        ens = st.session_state["ensemble"]

        # --- 1. Unsupervised models scored against ground truth ---
        st.markdown("#### Unsupervised models vs ground truth")
        eval_df = evaluate_unsupervised(results, ens, y_true)
        st.dataframe(eval_df, use_container_width=True, hide_index=True)

        metric_long = eval_df.melt(
            id_vars="Model",
            value_vars=[c for c in ["Precision", "Recall", "F1-score"] if c in eval_df],
            var_name="Metric", value_name="Score",
        )
        fig = px.bar(
            metric_long, x="Model", y="Score", color="Metric", barmode="group",
            title="Precision / Recall / F1 by model",
            color_discrete_sequence=["#22d3ee", "#34d399", "#fbbf24"],
        )
        fig.update_layout(template="plotly_dark", height=380, margin=dict(t=50))
        st.plotly_chart(fig, use_container_width=True)

        # Confusion matrix for the best unsupervised model (by F1)
        best_row = eval_df.iloc[eval_df["F1-score"].astype(float).idxmax()]
        best_name = best_row["Model"]
        if best_name in results:
            from src.models import confusion_for
            cm_best = confusion_for(results[best_name]["pred"], y_true)
            st.plotly_chart(
                _confusion_heatmap(cm_best, f"Confusion matrix — {best_name}"),
                use_container_width=True,
            )

        st.divider()

        # --- 2. Supervised Random Forest ---
        st.markdown("#### Supervised Random Forest classifier")
        st.caption(
            "Trains on 70% of the labeled packets and is evaluated on a "
            "held-out 30% test split."
        )
        if st.button("Train Random Forest", type="primary"):
            with st.spinner("Training Random Forest..."):
                X = st.session_state["scaled_X"]
                rf = train_supervised_rf(X, y_true, test_size=0.3)
                st.session_state["rf"] = rf

        if "rf" in st.session_state:
            rf = st.session_state["rf"]
            m = rf["metrics"]
            cols = st.columns(5)
            cols[0].metric("Accuracy", f"{m['Accuracy'] * 100:.1f}%")
            cols[1].metric("Precision", f"{m['Precision'] * 100:.1f}%")
            cols[2].metric("Recall", f"{m['Recall'] * 100:.1f}%")
            cols[3].metric("F1-score", f"{m['F1-score'] * 100:.1f}%")
            cols[4].metric("ROC-AUC", f"{m.get('ROC-AUC', float('nan')):.3f}")
            st.caption(f"Trained on {rf['n_train']} packets, tested on {rf['n_test']}.")

            left, right = st.columns(2)
            with left:
                st.plotly_chart(
                    _confusion_heatmap(rf["confusion"], "Confusion matrix — Random Forest"),
                    use_container_width=True,
                )
            with right:
                if rf["roc"] is not None:
                    roc = rf["roc"]
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=roc["fpr"], y=roc["tpr"], mode="lines",
                        name="ROC", line=dict(color=ACCENT, width=3),
                    ))
                    fig.add_trace(go.Scatter(
                        x=[0, 1], y=[0, 1], mode="lines",
                        name="Random", line=dict(color="#64748b", dash="dash"),
                    ))
                    fig.update_layout(
                        template="plotly_dark", height=360,
                        title="ROC curve",
                        xaxis_title="False positive rate",
                        yaxis_title="True positive rate",
                        margin=dict(t=50),
                    )
                    st.plotly_chart(fig, use_container_width=True)

            st.markdown("##### Feature importance")
            imp = rf["importances"]
            fig = px.bar(
                imp, x="importance", y="feature", orientation="h",
                title="Which features drive the predictions",
                color_discrete_sequence=[ACCENT],
            )
            fig.update_layout(
                template="plotly_dark", height=400,
                yaxis=dict(autorange="reversed"), margin=dict(t=50),
            )
            st.plotly_chart(fig, use_container_width=True)
