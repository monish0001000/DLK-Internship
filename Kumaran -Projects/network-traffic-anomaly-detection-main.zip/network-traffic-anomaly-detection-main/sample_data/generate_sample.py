"""
Generate a synthetic Wireshark-style CSV for quick testing.

Produces mostly "normal" web/DNS traffic plus a small number of injected
anomalies (a port-scan burst and a large data exfiltration flow).

Run:
    python sample_data/generate_sample.py
"""

import csv
import random

random.seed(42)

OUT = "sample_data/sample_traffic.csv"

NORMAL_IPS = [f"192.168.1.{i}" for i in range(2, 30)]
SERVERS = ["142.250.190.78", "151.101.1.69", "104.16.85.20", "8.8.8.8"]
PROTOCOLS = ["TCP", "UDP", "TCP", "TCP", "UDP"]

rows = []
t = 0.0
no = 1

# --- Normal traffic ---
for _ in range(900):
    t += random.uniform(0.001, 0.05)
    src = random.choice(NORMAL_IPS)
    dst = random.choice(SERVERS)
    proto = random.choice(PROTOCOLS)
    length = random.randint(60, 1500)
    sport = random.randint(1024, 65535)
    dport = random.choice([80, 443, 53])
    info = f"{sport} -> {dport} [ACK] Len={length - 54}"
    rows.append([no, round(t, 6), src, dst, proto, length, sport, dport, info, 0])
    no += 1

# --- Anomaly 1: port scan (one src hits many ports on one dst, tiny packets) ---
attacker = "192.168.1.66"
target = "192.168.1.10"
for port in range(20, 90):
    t += random.uniform(0.0001, 0.001)
    rows.append([no, round(t, 6), attacker, target, "TCP", 60,
                 random.randint(40000, 41000), port, f"{port} [SYN] scan", 1])
    no += 1

# --- Anomaly 2: large data exfiltration (huge packets to an unusual dst) ---
exfil_dst = "45.13.22.199"
for _ in range(25):
    t += random.uniform(0.01, 0.03)
    rows.append([no, round(t, 6), "192.168.1.15", exfil_dst, "TCP", random.randint(9000, 15000),
                 50000, 4444, "data transfer", 1])
    no += 1

random.shuffle(rows)
# Re-number after shuffle so "No." stays sequential
for i, r in enumerate(rows, start=1):
    r[0] = i

with open(OUT, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["No.", "Time", "Source", "Destination", "Protocol",
                "Length", "tcp.srcport", "tcp.dstport", "Info", "Label"])
    w.writerows(rows)

print(f"Wrote {len(rows)} packets to {OUT}")
