# Network Traffic Anomaly Detection using Machine Learning
### Project Report & PPT Content (Wireshark + scikit-learn)

> Ready-to-use content for your college report and PowerPoint presentation.
> Each "Slide" heading can become one PPT slide. The report sections can be
> pasted directly into a Word/LaTeX document.

---

## 1. Abstract

Modern networks generate huge volumes of traffic, and malicious activity such
as port scans, denial-of-service floods, and data exfiltration often hides
inside otherwise normal-looking flows. Manually inspecting packets does not
scale. This project presents a **machine-learning based Network Traffic Anomaly
Detection system** that captures live traffic using **Wireshark**, converts each
packet into numerical features, and applies **scikit-learn** models to flag
abnormal behaviour automatically.

The system compares three unsupervised detectors — **Isolation Forest**,
**One-Class SVM**, and **Local Outlier Factor (LOF)** — combined through an
**ensemble majority vote**, and also includes a supervised **Random Forest**
classifier for labeled captures. An interactive **Streamlit dashboard** lets the
user upload a capture, run detection, compare models, and explore the flagged
packets visually. On a labeled test dataset the supervised model achieves high
precision and recall, while the unsupervised ensemble detects injected attacks
without any prior labels.

---

## 2. Problem Statement

Traditional signature-based intrusion detection systems can only catch *known*
attacks. They fail against new or disguised threats and require constant rule
updates. There is a need for a system that learns the *normal* pattern of a
network and automatically flags **any** deviation from it, with minimal manual
configuration.

---

## 3. Objectives

- Capture and parse real network traffic from Wireshark (CSV and .pcap).
- Engineer meaningful per-packet and per-flow features.
- Detect anomalies using multiple unsupervised ML models.
- Combine models through an ensemble for more robust detection.
- Provide a supervised classifier and full evaluation metrics for labeled data.
- Present results through an interactive, visual dashboard.

---

## 4. Literature Survey (summary points)

| Approach | Description | Limitation |
|----------|-------------|------------|
| Signature-based IDS (e.g. Snort) | Matches traffic against known attack rules | Cannot detect unknown/zero-day attacks |
| Statistical thresholding | Flags traffic above fixed thresholds | High false alarms, manual tuning |
| Clustering (K-Means) | Groups similar traffic, outliers = anomaly | Sensitive to scaling & cluster count |
| **Isolation Forest** | Isolates anomalies via random partitioning | Needs contamination estimate |
| **One-Class SVM** | Learns a boundary around normal data | Slower on large data |
| **Supervised (Random Forest)** | Learns from labeled attacks | Needs labeled training data |

Our project combines several of these to balance their individual weaknesses.

---

## 5. System Architecture

```
        ┌──────────────────┐
        │  Network Traffic │
        └────────┬─────────┘
                 │ capture
        ┌────────▼─────────┐
        │    Wireshark     │  (.pcap / CSV export)
        └────────┬─────────┘
                 │ upload
        ┌────────▼─────────┐
        │ Feature Extraction│ (length, ports, inter-arrival,
        │  + Engineering    │  flow counts, port-scan signals)
        └────────┬─────────┘
                 │
        ┌────────▼─────────┐
        │  Preprocessing   │  (StandardScaler)
        └────────┬─────────┘
                 │
        ┌────────▼──────────────────────────┐
        │            ML Layer                │
        │  Isolation Forest │ One-Class SVM  │
        │  LOF │ Ensemble │ Random Forest    │
        └────────┬──────────────────────────┘
                 │
        ┌────────▼─────────┐
        │   Streamlit UI   │  (charts, tables, metrics, CSV export)
        └──────────────────┘
```

---

## 6. Methodology / Workflow

1. **Data Collection** — Capture traffic in Wireshark; export as CSV
   (`File → Export Packet Dissections → As CSV`) or save the raw `.pcap`.
2. **Feature Extraction** — Parse each packet and compute features:
   - Packet length, inter-arrival time
   - Source/destination ports
   - Protocol one-hot (TCP/UDP/ICMP)
   - Per-source packet count and total bytes (catches floods)
   - Per-destination unique port count (catches port scans)
3. **Preprocessing** — Standardise features (zero mean, unit variance) so that
   distance-based models work correctly.
4. **Modelling** — Run Isolation Forest, One-Class SVM, and LOF; combine with an
   ensemble majority vote. Optionally train a Random Forest on labeled data.
5. **Evaluation** — Compute Accuracy, Precision, Recall, F1-score, ROC-AUC and a
   confusion matrix (when ground-truth labels are available).
6. **Visualisation** — Show protocol distribution, packet timeline with
   anomalies highlighted, model comparison, and downloadable results.

---

## 7. Tools & Technologies

| Layer | Tool |
|-------|------|
| Packet capture | Wireshark / tshark |
| Language | Python 3 |
| Data handling | Pandas, NumPy |
| Machine learning | scikit-learn |
| pcap parsing | scapy |
| Visualisation | Plotly |
| Dashboard / UI | Streamlit |

---

## 8. Algorithms Used

- **Isolation Forest** — Randomly partitions data; anomalies are isolated in
  fewer splits, giving them a higher anomaly score. Best general-purpose detector.
- **One-Class SVM** — Learns a tight boundary around "normal" traffic; points
  outside are anomalies.
- **Local Outlier Factor (LOF)** — Compares the local density of a point to its
  neighbours; low-density points are outliers.
- **Ensemble (Majority Vote)** — A packet is flagged if at least half of the
  models flag it, reducing individual model errors.
- **Random Forest (supervised)** — An ensemble of decision trees trained on
  labeled data; provides the highest accuracy when labels are available and
  reports feature importance.

---

## 9. Results & Discussion

On the bundled labeled sample (900 normal packets + 95 injected anomalies:
a port scan and a data-exfiltration burst):

**Unsupervised models (scored against ground truth):**

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|-------|----------|-----------|--------|-----|---------|
| Isolation Forest | 0.91 | 0.53 | 0.44 | 0.48 | 0.96 |
| One-Class SVM | 0.89 | 0.38 | 0.33 | 0.35 | 0.83 |
| LOF | 0.83 | 0.03 | 0.02 | 0.02 | 0.31 |
| Ensemble | 0.90 | 0.46 | 0.27 | 0.34 | — |

**Supervised Random Forest (70/30 train-test split):**

| Accuracy | Precision | Recall | F1 | ROC-AUC |
|----------|-----------|--------|-----|---------|
| 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |

*Top features:* per-source packet count, packet length, destination unique-port
count — exactly the signals that characterise scans and exfiltration.

**Discussion:** Isolation Forest is the strongest unsupervised detector
(ROC-AUC 0.96). Random Forest is near-perfect but requires labels. The numbers
above are on synthetic data; on real captures expect lower, more realistic
scores. Tune the *contamination* slider to trade off precision vs recall.

---

## 10. Conclusion

The project demonstrates an end-to-end pipeline that turns raw Wireshark
captures into actionable anomaly alerts using machine learning. By combining
multiple unsupervised models with an optional supervised classifier and an
interactive dashboard, it detects both known and unknown attack patterns
without manual rule-writing.

## 11. Future Enhancements

- Real-time live capture and streaming detection.
- Deep-learning models (Autoencoders, LSTM) for sequential traffic.
- Integration with a standard dataset (NSL-KDD, CICIDS2017) for benchmarking.
- Email/Slack alerting when anomalies cross a threshold.
- Deployment as a continuously running network monitor.

---

## Suggested PPT Slide Order

1. Title + team details
2. Abstract / Problem statement
3. Objectives
4. Literature survey
5. System architecture (diagram)
6. Methodology / workflow
7. Tools & technologies
8. Algorithms used
9. Dashboard screenshots (Overview, Model comparison, Metrics)
10. Results table
11. Conclusion & future work
12. Demo / Q&A
