# Network Traffic Anomaly Detection

Detect suspicious network activity (port scans, floods, unusual data transfers)
from captured traffic using **Wireshark** for data collection and
**scikit-learn** for unsupervised anomaly detection — all wrapped in an
interactive **Streamlit** dashboard.

---

## How it works (Workflow)

```
Network Traffic
      |
Wireshark  (capture .pcap  ->  Export as CSV)   OR   raw .pcap / .pcapng
      |
Feature Extraction      (src/feature_extraction.py)
      |
Preprocessing / Scaling (src/preprocessing.py)
      |
ML Models               (src/models.py)
   - Isolation Forest
   - One-Class SVM
   - Local Outlier Factor (LOF)
   - Ensemble majority vote
      |
Dashboard  (app.py)  ->  visualise + download results
```

1. **Capture** traffic in Wireshark.
2. **Export** it as CSV (`File -> Export Packet Dissections -> As CSV`) or save the raw `.pcap`.
3. **Upload** the file to the dashboard (or use the bundled sample).
4. Features are extracted and standardised, then three unsupervised detectors run.
5. An **ensemble majority vote** highlights the most suspicious packets, which you can explore and download.

---

## Project structure

```
.
├── app.py                       # Streamlit dashboard (UI + orchestration)
├── src/
│   ├── feature_extraction.py    # CSV / pcap parsing + feature engineering
│   ├── preprocessing.py         # StandardScaler scaling
│   └── models.py                # Unsupervised models, ensemble, Random Forest, metrics
├── sample_data/
│   ├── generate_sample.py       # Creates synthetic labeled test traffic
│   └── sample_traffic.csv       # Bundled demo capture (with injected attacks + labels)
├── docs/
│   └── REPORT_AND_PPT_CONTENT.md # Report write-up + PPT slide outline
├── requirements.txt
└── .streamlit/config.toml       # Theme + server config
```

---

## Setup & Run

```bash
# 1. Create a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the dashboard
streamlit run app.py
```

Then open http://localhost:8501 in your browser.

---

## Using your own Wireshark data

### Option A — CSV export (easiest)
1. Capture in Wireshark.
2. `File -> Export Packet Dissections -> As CSV`.
3. Upload the CSV in the sidebar. The app auto-detects common columns
   (`Source`, `Destination`, `Protocol`, `Length`, `Time`, ports).

### Option B — tshark command line
```bash
tshark -r capture.pcap -T fields \
  -e frame.time_relative -e ip.src -e ip.dst -e ip.proto \
  -e frame.len -e tcp.srcport -e tcp.dstport \
  -E header=y -E separator=, > traffic.csv
```

### Option C — raw pcap
Upload the `.pcap` / `.pcapng` directly — it is parsed with **scapy** (no tshark needed).

---

## The models

| Model | Type | Strength |
|-------|------|----------|
| Isolation Forest | Unsupervised | Fast, robust general-purpose anomaly detection |
| One-Class SVM | Unsupervised | Learns a tight boundary around normal traffic |
| Local Outlier Factor | Unsupervised | Density-based, good for local outliers |
| **Ensemble** | Majority vote | Flags a packet only when most models agree |
| **Random Forest** | Supervised | Highest accuracy when labeled data is available |

Convention: prediction `1 = normal`, `-1 = anomaly`. The **contamination**
slider controls how aggressive detection is (expected anomaly fraction).

---

## Evaluation metrics & supervised model (labeled data)

If your capture includes a **`Label`** column (`0` = normal, `1` = anomaly —
text such as `normal` / `attack` also works), the **"Supervised & Metrics"**
tab unlocks:

- **Accuracy, Precision, Recall, F1-score, ROC-AUC** for every unsupervised model
  scored against the ground truth.
- A **confusion matrix** for the best-performing unsupervised model.
- A supervised **Random Forest** classifier (70/30 train-test split) with its own
  confusion matrix, **ROC curve**, and **feature-importance** chart.

The bundled sample data is already labeled, so this tab works out of the box.

For a full project write-up (abstract, literature survey, methodology, results
and a slide-by-slide PPT outline) see **`docs/REPORT_AND_PPT_CONTENT.md`**.

---

## Engineered features

`length`, `inter_arrival` time, `src_port`, `dst_port`, protocol one-hots
(`is_tcp`, `is_udp`, `is_icmp`), per-source `src_pkt_count` and
`src_total_bytes`, and per-destination `dst_unique_ports` (which exposes
port-scan behaviour).

---

## Regenerate the sample data

```bash
python sample_data/generate_sample.py
```
This creates ~995 packets of normal traffic plus injected anomalies
(a port-scan burst and a data-exfiltration flow) so you can immediately
see the detectors working.
