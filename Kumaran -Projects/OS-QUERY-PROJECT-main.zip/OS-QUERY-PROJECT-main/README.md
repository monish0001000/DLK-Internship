# OS-QUERY-PROJECT
By using the os i build the project
