# 🛡 EndSight-OS
## AI-Powered Endpoint Security, Threat Hunting & Digital Forensics Platform

---

## 🚀 Quick Start (Windows)

1. **Extract** the ZIP file anywhere
2. **Double-click** `START.bat`
3. Browser opens automatically → `http://localhost:3000`

**Requirements:** Python 3.9+ and Node.js 18+ must be installed.

---

## 🚀 Quick Start (Linux / Mac)

```bash
chmod +x start.sh
./start.sh
```

---

## 📦 Prerequisites

| Tool | Download | Required |
|------|----------|----------|
| Python 3.9+ | https://python.org | ✅ Yes |
| Node.js 18+ | https://nodejs.org | ✅ Yes |
| pip | Comes with Python | ✅ Yes |

---

## 🏗 Project Structure

```
endsight-os/
├── START.bat                   ← Windows launcher (double-click this)
├── start.sh                    ← Linux/Mac launcher
├── README.md
├── backend/
│   ├── main.py                 ← FastAPI server (all API endpoints)
│   ├── database.py             ← SQLite database setup
│   ├── requirements.txt        ← Python packages
│   ├── endsight.db             ← Auto-created database
│   ├── collectors/
│   │   └── system_collector.py ← Real data collection (psutil, WMI, registry)
│   └── ai/
│       ├── risk_engine.py      ← AI multi-factor risk scoring
│       └── threat_hunter.py    ← Automated threat hunting engine
└── frontend/
    ├── src/
    │   ├── App.jsx             ← All 16 pages/modules
    │   ├── index.css           ← Dark cybersecurity theme
    │   └── main.jsx
    ├── package.json
    └── vite.config.js
```

---

## 📊 Modules (All 15 implemented)

| Module | What it does | Data Source |
|--------|-------------|-------------|
| 🖥 Endpoint Inventory | Hardware, OS, BIOS info | psutil, WMI |
| ⚡ Live Process Monitor | All running processes with risk | psutil |
| 🌐 Network Monitor | Connections, suspicious IPs/ports | psutil |
| 🔌 USB Security | Detect, track, authorize USB devices | WMI (Windows) |
| 🔁 Startup / Persistence | Registry, scheduled tasks | winreg, schtasks |
| 👤 User Activity | Login events, failed auth, RDP | Windows Event Log |
| 📦 Software Inventory | Installed apps, blacklist check | Windows Registry |
| 🔒 Security Config | Firewall, Defender, BitLocker, UAC | PowerShell, WMI |
| 📄 File Integrity | SHA-256 hash monitoring | OS filesystem |
| 🌍 Browser Extensions | Chrome, Firefox extension audit | Browser profiles |
| 🎯 Threat Hunting | LOLBin, encoded cmds, C2, brute force | Database correlation |
| 🤖 AI Risk Engine | 7-factor weighted risk scoring | All modules |
| 🔔 Alert Center | Real-time alerts, resolve, filter | Auto-generated |
| ⏱ Timeline | Chronological security events | All modules |
| 🔍 Digital Forensics | Process/USB/login/software history | Database |

---

## 🤖 AI Features

### Risk Scoring
- **7 risk categories** with individual scores (0-100%)
- **Weighted overall score** with custom weights per category
- **Attack probability** and **compromise probability** predictions

### Threat Classification
- Malware Activity
- Persistence / Rootkit
- C2 Communication
- Credential Abuse / Brute Force
- USB-Based Attack Vector
- Insider Threat

### Threat Hunting (Auto)
- LOLBin abuse (Office spawning PowerShell/CMD)
- Encoded/obfuscated command detection
- Suspicious parent-child process chains
- C2 communication port detection (4444, 1337, 31337, etc.)
- Credential brute force patterns
- Ransomware indicators
- Off-hours user activity
- Insider threat patterns

---

## 🔌 API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/dashboard` | Full dashboard data |
| `GET /api/processes` | All running processes |
| `GET /api/network` | Network connections |
| `GET /api/usb` | USB devices |
| `POST /api/usb/{serial}/authorize` | Authorize USB device |
| `GET /api/startup` | Startup/persistence entries |
| `GET /api/users` | User activity events |
| `GET /api/software` | Installed software |
| `GET /api/security-config` | Security configuration |
| `GET /api/file-integrity` | File change events |
| `GET /api/browser` | Browser extensions |
| `GET /api/threats` | Threat hunting results |
| `GET /api/risk` | AI risk analysis |
| `GET /api/alerts` | Active alerts |
| `POST /api/alerts/{id}/resolve` | Resolve alert |
| `GET /api/timeline` | Timeline events |
| `GET /api/forensics` | Digital forensics data |
| `GET /api/settings` | Platform settings |
| `POST /api/collect` | Trigger manual collection |
| `GET /api/health` | Health check |

**API Docs:** http://localhost:8000/docs (Swagger UI)

---

## ⚙️ Configuration

Settings are available in the Dashboard → Settings page:

- **Collection Interval**: How often data is collected (default: 60s)
- **Alert Email**: For email notifications
- **Webhook URL**: For webhook alerts
- **Monitor Paths**: Paths for file integrity monitoring
- **Threat Hunting**: Enable/disable auto threat hunting
- **USB Policy**: Monitor only vs Block unauthorized

---

## 🔐 Data Sources by OS

| Feature | Windows | Linux/Mac |
|---------|---------|-----------|
| Process monitoring | ✅ Full | ✅ Full |
| Network connections | ✅ Full | ✅ Full |
| USB detection | ✅ WMI | ❌ (Windows only) |
| Registry startup entries | ✅ winreg | ❌ (Windows only) |
| Scheduled tasks | ✅ schtasks | ❌ (Windows only) |
| Windows Event Log | ✅ PowerShell | ❌ (Windows only) |
| Software inventory | ✅ Registry | ❌ (Windows only) |
| Security config | ✅ Full | ⚠️ Partial |
| File integrity | ✅ Full | ✅ Full |
| Browser extensions | ✅ Chrome/Firefox | ✅ Chrome/Firefox |

---

## 🗺 Future Roadmap

- [ ] Multi-endpoint support
- [ ] MITRE ATT&CK technique mapping
- [ ] Email/Webhook notification delivery
- [ ] YARA scan integration
- [ ] SIEM integration (Splunk/Elastic)
- [ ] PDF report export
- [ ] Role-based access control
- [ ] Cloud dashboard
- [ ] Mobile admin app

---

## ⚠️ Ethical Use

This platform is designed for **monitoring your own endpoint** or endpoints you are authorized to monitor. Do not use on systems without explicit permission. This tool is for defensive security purposes only.

---

## 📞 Troubleshooting

**Backend won't start:**
```bash
cd backend
pip install -r requirements.txt
python main.py
```

**Frontend won't start:**
```bash
cd frontend
npm install
npm run dev
```

**No data showing:**
- Ensure backend is running on port 8000
- Click "Refresh Now" on Dashboard
- Check browser console for errors
- On non-Windows systems, some modules return no data (Windows-only features)

**Port already in use:**
- Kill existing processes: `taskkill /f /im python.exe` (Windows)
- Change port in `vite.config.js` and `main.py` if needed
