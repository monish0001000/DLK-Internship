"""
Real system data collector using psutil + Windows APIs
Collects live data from the running endpoint
"""
import psutil
import platform
import socket
import subprocess
import hashlib
import os
import sys
import datetime
import json

def now():
    return datetime.datetime.now().isoformat()

# ── Device Info ──────────────────────────────────────────
def collect_device_info():
    try:
        hostname = socket.gethostname()
        try:
            ip = socket.gethostbyname(hostname)
        except:
            ip = "127.0.0.1"

        cpu = platform.processor() or "Unknown CPU"
        cpu_cores = psutil.cpu_count(logical=True) or 1
        ram = round(psutil.virtual_memory().total / (1024**3), 1)

        try:
            disk = psutil.disk_usage("C:\\" if sys.platform == "win32" else "/")
            disk_total = round(disk.total / (1024**3), 1)
            disk_free = round(disk.free / (1024**3), 1)
        except:
            disk_total = disk_free = 0

        uptime_seconds = int(datetime.datetime.now().timestamp() - psutil.boot_time())

        bios_vendor = "Unknown"
        bios_version = "Unknown"
        mac = "Unknown"

        if sys.platform == "win32":
            try:
                import wmi
                w = wmi.WMI()
                for bios in w.Win32_BIOS():
                    bios_vendor = bios.Manufacturer or "Unknown"
                    bios_version = bios.SMBIOSBIOSVersion or "Unknown"
                for nic in w.Win32_NetworkAdapterConfiguration(IPEnabled=True):
                    if nic.MACAddress:
                        mac = nic.MACAddress
                        break
            except:
                pass
        else:
            # Linux/Mac: try to get MAC
            try:
                import uuid
                mac = ':'.join(['{:02x}'.format((uuid.getnode() >> i) & 0xff) for i in range(0,48,8)][::-1])
            except:
                pass

        return {
            "hostname": hostname,
            "username": os.getenv("USERNAME") or os.getenv("USER") or "unknown",
            "os_version": platform.version()[:100],
            "os_build": platform.release(),
            "cpu": cpu[:100],
            "cpu_cores": cpu_cores,
            "ram_gb": ram,
            "disk_total_gb": disk_total,
            "disk_free_gb": disk_free,
            "bios_vendor": bios_vendor[:50],
            "bios_version": bios_version[:50],
            "ip_address": ip,
            "mac_address": mac,
            "uptime_seconds": uptime_seconds,
            "last_seen": now(),
            "status": "online"
        }
    except Exception as e:
        print(f"[Collector] Device info error: {e}")
        return {"hostname": "unknown", "status": "online", "last_seen": now()}

# ── Processes ────────────────────────────────────────────
SUSPICIOUS_NAMES = {
    "mimikatz.exe","pwdump.exe","procdump.exe","wce.exe",
    "fgdump.exe","gsecdump.exe","cachedump.exe","meterpreter.exe",
    "payload.exe","shell.exe","nc.exe","ncat.exe"
}
SUSPICIOUS_PATHS_PARTS = ["\\temp\\","\\tmp\\","\\appdata\\local\\temp\\","\\users\\public\\"]
LOLBINS = {
    "powershell.exe","cmd.exe","wscript.exe","cscript.exe",
    "mshta.exe","rundll32.exe","regsvr32.exe","certutil.exe",
    "bitsadmin.exe","wmic.exe","msiexec.exe","installutil.exe"
}

def is_process_signed(path):
    if not path or not os.path.exists(path):
        return False
    if sys.platform == "win32":
        try:
            result = subprocess.run(
                ["powershell","-Command",f"(Get-AuthenticodeSignature '{path}').Status"],
                capture_output=True, text=True, timeout=3
            )
            return "Valid" in result.stdout
        except:
            pass
    low = (path or "").lower()
    return "system32" in low or "program files" in low or "windows" in low

def get_process_risk(proc_info):
    name = (proc_info.get("name") or "").lower()
    path = (proc_info.get("path") or "").lower()
    parent = (proc_info.get("parent_name") or "").lower()
    if name in SUSPICIOUS_NAMES:
        return "critical"
    if any(sp in path for sp in SUSPICIOUS_PATHS_PARTS) and name.endswith(".exe"):
        return "high"
    if name in LOLBINS and parent in LOLBINS:
        return "high"
    if not proc_info.get("is_signed") and path and name.endswith(".exe"):
        return "medium"
    return "low"

def collect_processes():
    results = []
    seen_pids = set()
    for proc in psutil.process_iter(['pid','name','exe','cmdline','ppid',
                                      'cpu_percent','memory_info','create_time',
                                      'username','status']):
        try:
            info = proc.info
            pid = info['pid']
            if pid in seen_pids:
                continue
            seen_pids.add(pid)
            name  = info.get('name') or ''
            path  = info.get('exe') or ''
            cmdline = ' '.join(info.get('cmdline') or [])[:500]
            ppid  = info.get('ppid') or 0
            parent_name = ''
            try:
                if ppid:
                    parent_name = psutil.Process(ppid).name()
            except:
                pass
            cpu = round(info.get('cpu_percent') or 0, 1)
            mem_info = info.get('memory_info')
            mem_mb = round((mem_info.rss if mem_info else 0) / (1024*1024), 1)
            ct = info.get('create_time')
            start_time = datetime.datetime.fromtimestamp(ct).isoformat() if ct else now()
            username = info.get('username') or 'SYSTEM'
            status   = info.get('status') or 'unknown'
            is_signed = 1 if is_process_signed(path) else 0
            proc_data = {
                "pid": pid, "name": name, "path": path, "cmdline": cmdline,
                "parent_pid": ppid, "parent_name": parent_name,
                "cpu_percent": cpu, "memory_mb": mem_mb,
                "start_time": start_time, "username": username,
                "status": status, "is_signed": is_signed, "is_hidden": 0,
                "collected_at": now()
            }
            proc_data["risk_level"] = get_process_risk(proc_data)
            results.append(proc_data)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        except Exception:
            continue
    return results

# ── Network ──────────────────────────────────────────────
SUSPICIOUS_PORTS = {4444,1337,31337,8888,9999,6666,6667,1234,12345,4445,5555}

def collect_network():
    results = []
    try:
        for conn in psutil.net_connections(kind='all'):
            try:
                laddr = conn.laddr
                raddr = conn.raddr
                local_addr  = laddr.ip   if laddr else ""
                local_port  = laddr.port if laddr else 0
                remote_addr = raddr.ip   if raddr else ""
                remote_port = raddr.port if raddr else 0
                pid = conn.pid or 0
                proc_name = ""
                try:
                    if pid:
                        proc_name = psutil.Process(pid).name()
                except:
                    pass
                is_suspicious = 1 if remote_port in SUSPICIOUS_PORTS else 0
                results.append({
                    "local_address": local_addr,
                    "local_port": local_port,
                    "remote_address": remote_addr,
                    "remote_port": remote_port,
                    "protocol": "TCP" if conn.type == 1 else "UDP",
                    "state": conn.status or "",
                    "pid": pid,
                    "process_name": proc_name,
                    "country": "Unknown",
                    "is_suspicious": is_suspicious,
                    "is_known_bad": 0,
                    "collected_at": now()
                })
            except:
                continue
    except Exception as e:
        print(f"[Collector] Network error: {e}")
    return results

# ── USB Devices ──────────────────────────────────────────
def collect_usb():
    results = []
    if sys.platform != "win32":
        return results
    try:
        import wmi
        w = wmi.WMI()
        for disk in w.Win32_DiskDrive():
            if disk.InterfaceType and "USB" in disk.InterfaceType:
                size_gb = round(int(disk.Size or 0) / (1024**3), 1) if disk.Size else 0
                results.append({
                    "event_type": "connected",
                    "vendor": disk.Manufacturer or "Unknown",
                    "product": disk.Model or "Unknown USB",
                    "serial_number": (disk.SerialNumber or "UNKNOWN").strip(),
                    "device_id": disk.DeviceID or "",
                    "size_gb": size_gb,
                    "drive_letter": "",
                    "last_seen": now()
                })
    except Exception as e:
        print(f"[Collector] USB error: {e}")
    return results

# ── Startup Entries ──────────────────────────────────────
def collect_startup():
    results = []
    if sys.platform == "win32":
        try:
            import winreg
            reg_paths = [
                (winreg.HKEY_CURRENT_USER,  r"Software\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
            ]
            for hive, path in reg_paths:
                try:
                    key = winreg.OpenKey(hive, path)
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(key, i)
                            exe_path = value.split('"')[1] if '"' in value else value.split()[0]
                            is_susp = 1 if any(s in exe_path.lower() for s in ["temp","tmp","public","appdata\\local\\temp"]) else 0
                            results.append({
                                "name": name, "path": exe_path, "command": value,
                                "type": "registry", "registry_key": path,
                                "is_new": 0, "is_suspicious": is_susp, "collected_at": now()
                            })
                            i += 1
                        except OSError:
                            break
                    winreg.CloseKey(key)
                except:
                    continue
        except ImportError:
            pass
        # Scheduled Tasks
        try:
            r = subprocess.run(["schtasks","/query","/fo","CSV","/v"],
                               capture_output=True, text=True, timeout=10)
            lines = r.stdout.strip().split('\n')
            for line in lines[1:]:
                parts = line.split('","')
                if len(parts) > 8:
                    task_name = parts[0].strip('"')
                    task_path = parts[8].strip('"') if len(parts) > 8 else ""
                    if task_name and task_name not in ("TaskName",""):
                        is_susp = 1 if any(s in task_path.lower() for s in ["temp","tmp","public"]) else 0
                        results.append({
                            "name": task_name[:100], "path": task_path[:300],
                            "command": task_path[:300], "type": "scheduled_task",
                            "registry_key": "", "is_new": 0,
                            "is_suspicious": is_susp, "collected_at": now()
                        })
        except:
            pass
    return results

# ── Software Inventory ───────────────────────────────────
def collect_software(blacklist):
    results = []
    if sys.platform == "win32":
        try:
            import winreg
            reg_paths = [
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
                (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
            ]
            seen = set()
            for hive, path in reg_paths:
                try:
                    key = winreg.OpenKey(hive, path)
                    for i in range(winreg.QueryInfoKey(key)[0]):
                        try:
                            subkey_name = winreg.EnumKey(key, i)
                            subkey = winreg.OpenKey(key, subkey_name)
                            def gv(k, n):
                                try: return winreg.QueryValueEx(k, n)[0]
                                except: return ""
                            name = gv(subkey, "DisplayName")
                            if not name or name in seen:
                                continue
                            seen.add(name)
                            version   = gv(subkey, "DisplayVersion")
                            publisher = gv(subkey, "Publisher")
                            inst_date = gv(subkey, "InstallDate")
                            inst_loc  = gv(subkey, "InstallLocation")
                            size      = gv(subkey, "EstimatedSize")
                            size_mb   = round(int(size) / 1024, 1) if size else 0
                            is_black  = 1 if any(b.lower() in name.lower() for b in blacklist) else 0
                            results.append({
                                "name": name[:200], "version": version[:50],
                                "publisher": publisher[:100], "install_date": inst_date,
                                "install_location": inst_loc[:300], "size_mb": size_mb,
                                "is_blacklisted": is_black, "is_unauthorized": 0,
                                "collected_at": now()
                            })
                            winreg.CloseKey(subkey)
                        except:
                            continue
                    winreg.CloseKey(key)
                except:
                    continue
        except ImportError:
            pass
    return results

# ── Security Config ──────────────────────────────────────
def collect_security_config():
    if sys.platform != "win32":
        return [{"item":"Platform","status":"unknown","value":"Windows required for full check","details":"","last_checked":now()}]
    checks = []

    # Firewall
    try:
        r = subprocess.run(["netsh","advfirewall","show","allprofiles","state"],
                           capture_output=True, text=True, timeout=5)
        on_count = r.stdout.lower().count("on")
        checks.append({"item":"Windows Firewall",
                        "status":"enabled" if on_count >= 2 else "disabled",
                        "value":"All profiles ON" if on_count >= 2 else f"{on_count}/3 profiles active",
                        "details":"","last_checked":now()})
    except:
        checks.append({"item":"Windows Firewall","status":"unknown","value":"Could not check","details":"","last_checked":now()})

    # Defender
    try:
        r = subprocess.run(["powershell","-Command",
            "Get-MpComputerStatus | Select-Object RealTimeProtectionEnabled,AntivirusEnabled | ConvertTo-Json"],
            capture_output=True, text=True, timeout=8)
        if r.stdout.strip():
            d = json.loads(r.stdout.strip())
            rtp = d.get("RealTimeProtectionEnabled",False)
            checks.append({"item":"Windows Defender",
                           "status":"enabled" if rtp else "disabled",
                           "value":f"Real-time: {'ON' if rtp else 'OFF'}",
                           "details":"","last_checked":now()})
        else: raise Exception()
    except:
        checks.append({"item":"Windows Defender","status":"unknown","value":"Could not check","details":"","last_checked":now()})

    # BitLocker
    try:
        r = subprocess.run(["manage-bde","-status","C:"],
                           capture_output=True, text=True, timeout=8)
        protected = "Protection On" in r.stdout
        checks.append({"item":"BitLocker",
                        "status":"enabled" if protected else "disabled",
                        "value":"C: Encrypted" if protected else "C: NOT Encrypted",
                        "details":"","last_checked":now()})
    except:
        checks.append({"item":"BitLocker","status":"unknown","value":"Could not check","details":"","last_checked":now()})

    # Secure Boot
    try:
        r = subprocess.run(["powershell","-Command","Confirm-SecureBootUEFI"],
                           capture_output=True, text=True, timeout=5)
        enabled = "True" in r.stdout
        checks.append({"item":"Secure Boot","status":"enabled" if enabled else "disabled",
                        "value":"Active" if enabled else "Inactive","details":"","last_checked":now()})
    except:
        checks.append({"item":"Secure Boot","status":"unknown","value":"Could not check","details":"","last_checked":now()})

    # TPM
    try:
        r = subprocess.run(["powershell","-Command",
            "Get-Tpm | Select-Object TpmPresent,TpmReady | ConvertTo-Json"],
            capture_output=True, text=True, timeout=5)
        if r.stdout.strip():
            d = json.loads(r.stdout.strip())
            ready = d.get("TpmReady",False)
            checks.append({"item":"TPM","status":"enabled" if ready else "disabled",
                           "value":f"Ready: {'Yes' if ready else 'No'}","details":"","last_checked":now()})
        else: raise Exception()
    except:
        checks.append({"item":"TPM","status":"unknown","value":"Could not check","details":"","last_checked":now()})

    # UAC
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                             r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System")
        val, _ = winreg.QueryValueEx(key, "EnableLUA")
        winreg.CloseKey(key)
        checks.append({"item":"UAC","status":"enabled" if val==1 else "disabled",
                        "value":"Active" if val==1 else "DISABLED - Risk","details":"","last_checked":now()})
    except:
        checks.append({"item":"UAC","status":"unknown","value":"Could not check","details":"","last_checked":now()})

    return checks

# ── User Activity ────────────────────────────────────────
def collect_user_activity():
    results = []
    if sys.platform != "win32":
        return results
    try:
        ps_cmd = """
        $events = Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624,4625,4634,4720,4726} -MaxEvents 50 -ErrorAction SilentlyContinue
        if ($events) {
            $events | ForEach-Object {
                $xml = [xml]$_.ToXml()
                $data = @{}
                foreach ($item in $xml.Event.EventData.Data) {
                    if ($item.Name) { $data[$item.Name] = $item.'#text' }
                }
                [PSCustomObject]@{
                    EventId=$_.Id
                    TimeCreated=$_.TimeCreated.ToString('yyyy-MM-ddTHH:mm:ss')
                    SubjectUserName=$data['SubjectUserName']
                    TargetUserName=$data['TargetUserName']
                    IpAddress=$data['IpAddress']
                    LogonType=$data['LogonType']
                }
            } | ConvertTo-Json -Compress
        }
        """
        r = subprocess.run(["powershell","-Command",ps_cmd],
                           capture_output=True, text=True, timeout=15)
        if r.stdout.strip():
            raw = r.stdout.strip()
            events = json.loads(raw) if raw.startswith('[') else [json.loads(raw)]
            event_map = {
                4624:("login","Successful logon",1),
                4625:("failed_login","Failed logon attempt",0),
                4634:("logout","User logged off",1),
                4720:("new_user","New user account created",1),
                4726:("user_deleted","User account deleted",1),
            }
            lt_map = {"2":"Interactive","3":"Network","10":"RemoteInteractive (RDP)"}
            for ev in events:
                eid = ev.get("EventId",0)
                if eid in event_map:
                    etype, details, success = event_map[eid]
                    username = ev.get("TargetUserName") or ev.get("SubjectUserName") or "unknown"
                    lt = lt_map.get(str(ev.get("LogonType","")), "")
                    if eid == 4624 and lt == "RemoteInteractive (RDP)":
                        etype = "rdp_login"; details = "Remote Desktop login"
                    results.append({
                        "username": username[:50], "event_type": etype,
                        "details": details, "ip_address": ev.get("IpAddress") or "",
                        "logon_type": lt, "success": success,
                        "event_id": eid, "collected_at": ev.get("TimeCreated") or now()
                    })
    except Exception as e:
        print(f"[Collector] User activity error: {e}")
    return results

# ── Browser Extensions ────────────────────────────────────
def collect_browser_extensions():
    results = []
    import json as _json
    chrome_path = os.path.expandvars("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Extensions")
    if os.path.exists(chrome_path):
        for ext_id in os.listdir(chrome_path):
            ext_dir = os.path.join(chrome_path, ext_id)
            if not os.path.isdir(ext_dir): continue
            name = ext_id; version = ""
            for ver_dir in os.listdir(ext_dir):
                manifest_path = os.path.join(ext_dir, ver_dir, "manifest.json")
                if os.path.exists(manifest_path):
                    try:
                        with open(manifest_path, "r", encoding="utf-8", errors="ignore") as f:
                            m = _json.load(f)
                            name = m.get("name", ext_id)[:100]
                            version = m.get("version","")
                    except: pass
                    break
            results.append({"browser":"Chrome","extension_name":name,
                            "extension_id":ext_id,"version":version,
                            "enabled":1,"is_suspicious":0,"collected_at":now()})
    return results
