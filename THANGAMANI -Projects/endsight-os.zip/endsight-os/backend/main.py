"""
EndSight-OS Backend - FastAPI
Real endpoint security monitoring platform
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import datetime, json, threading, time

from database import get_db, init_db
from collectors.system_collector import (
    collect_device_info, collect_processes, collect_network,
    collect_usb, collect_startup, collect_software,
    collect_security_config, collect_user_activity,
    collect_browser_extensions
)
from ai.risk_engine import RiskEngine
from ai.threat_hunter import ThreatHunter

def now():
    return datetime.datetime.now().isoformat()

# ── Background Collector ──────────────────────────────────
collection_running = False

def run_collection():
    global collection_running
    if collection_running:
        return
    collection_running = True
    try:
        print("[Collector] Starting data collection...")
        db = get_db()
        c  = db.cursor()

        # 1. Device info
        device = collect_device_info()
        if device:
            c.execute("""
                INSERT INTO devices (hostname,username,os_version,os_build,cpu,cpu_cores,
                    ram_gb,disk_total_gb,disk_free_gb,bios_vendor,bios_version,ip_address,
                    mac_address,uptime_seconds,last_seen,status)
                VALUES (:hostname,:username,:os_version,:os_build,:cpu,:cpu_cores,
                    :ram_gb,:disk_total_gb,:disk_free_gb,:bios_vendor,:bios_version,:ip_address,
                    :mac_address,:uptime_seconds,:last_seen,:status)
                ON CONFLICT(hostname) DO UPDATE SET
                    username=excluded.username, os_version=excluded.os_version,
                    cpu=excluded.cpu, ram_gb=excluded.ram_gb,
                    disk_total_gb=excluded.disk_total_gb, disk_free_gb=excluded.disk_free_gb,
                    ip_address=excluded.ip_address, uptime_seconds=excluded.uptime_seconds,
                    last_seen=excluded.last_seen, status=excluded.status
            """, device)

        # 2. Processes (clear old, insert fresh)
        procs = collect_processes()
        c.execute("DELETE FROM processes")
        for p in procs:
            c.execute("""
                INSERT OR IGNORE INTO processes
                (pid,name,path,cmdline,parent_pid,parent_name,cpu_percent,memory_mb,
                 start_time,username,status,is_signed,is_hidden,risk_level,collected_at)
                VALUES (:pid,:name,:path,:cmdline,:parent_pid,:parent_name,:cpu_percent,
                 :memory_mb,:start_time,:username,:status,:is_signed,:is_hidden,:risk_level,:collected_at)
            """, p)

        # 3. Network (clear old, insert fresh)
        nets = collect_network()
        c.execute("DELETE FROM network_connections")
        for n in nets:
            c.execute("""
                INSERT INTO network_connections
                (local_address,local_port,remote_address,remote_port,protocol,state,
                 pid,process_name,country,is_suspicious,is_known_bad,collected_at)
                VALUES (:local_address,:local_port,:remote_address,:remote_port,:protocol,
                 :state,:pid,:process_name,:country,:is_suspicious,:is_known_bad,:collected_at)
            """, n)

        # 4. USB
        usb_devices = collect_usb()
        for u in usb_devices:
            existing = c.execute("SELECT id FROM usb_events WHERE serial_number=?",
                                 (u['serial_number'],)).fetchone()
            if not existing:
                c.execute("""
                    INSERT INTO usb_events
                    (event_type,vendor,product,serial_number,device_id,size_gb,
                     drive_letter,is_authorized,first_seen,last_seen)
                    VALUES (:event_type,:vendor,:product,:serial_number,:device_id,:size_gb,
                     :drive_letter,0,:last_seen,:last_seen)
                """, u)
                # Check if authorized
                auth = c.execute("SELECT id FROM authorized_usb WHERE serial_number=?",
                                 (u['serial_number'],)).fetchone()
                if auth:
                    c.execute("UPDATE usb_events SET is_authorized=1 WHERE serial_number=?",
                              (u['serial_number'],))
                # Alert for unknown USB
                if not auth:
                    c.execute("""
                        INSERT INTO alerts (severity,title,description,module,created_at)
                        VALUES ('high','Unknown USB Device Connected',
                         'Unauthorized USB device detected: ? ? (S/N: ?)',
                         'usb',?)
                    """, (u['vendor'], u['product'], u['serial_number'], now()))
            else:
                c.execute("UPDATE usb_events SET last_seen=? WHERE serial_number=?",
                          (u['last_seen'], u['serial_number']))

        # 5. Startup entries
        startup = collect_startup()
        c.execute("DELETE FROM startup_entries")
        for s in startup:
            c.execute("""
                INSERT OR IGNORE INTO startup_entries
                (name,path,type,registry_key,command,is_new,is_suspicious,collected_at)
                VALUES (:name,:path,:type,:registry_key,:command,:is_new,:is_suspicious,:collected_at)
            """, s)

        # 6. Software
        blacklist = [row[0] for row in c.execute("SELECT name FROM blacklisted_software").fetchall()]
        software = collect_software(blacklist)
        c.execute("DELETE FROM software_inventory")
        for sw in software:
            c.execute("""
                INSERT INTO software_inventory
                (name,version,publisher,install_date,install_location,size_mb,
                 is_blacklisted,is_unauthorized,collected_at)
                VALUES (:name,:version,:publisher,:install_date,:install_location,
                 :size_mb,:is_blacklisted,:is_unauthorized,:collected_at)
            """, sw)

        # 7. Security config
        sec_config = collect_security_config()
        for cfg in sec_config:
            c.execute("""
                INSERT OR REPLACE INTO security_config (item,status,value,details,last_checked)
                VALUES (:item,:status,:value,:details,:last_checked)
            """, cfg)
            if cfg['status'] == 'disabled':
                c.execute("""
                    INSERT INTO alerts (severity,title,description,module,created_at)
                    VALUES ('high',?,?,?,?)
                """, (f"{cfg['item']} Disabled",
                      f"Security feature disabled: {cfg['item']} - {cfg['value']}",
                      'security_config', now()))

        # 8. User activity
        user_acts = collect_user_activity()
        for ua in user_acts:
            exists = c.execute("""
                SELECT id FROM user_activity
                WHERE username=? AND event_type=? AND collected_at=?
            """, (ua['username'], ua['event_type'], ua['collected_at'])).fetchone()
            if not exists:
                c.execute("""
                    INSERT INTO user_activity
                    (username,event_type,details,ip_address,logon_type,success,event_id,collected_at)
                    VALUES (:username,:event_type,:details,:ip_address,:logon_type,
                     :success,:event_id,:collected_at)
                """, ua)
                if not ua['success']:
                    c.execute("""
                        INSERT INTO alerts (severity,title,description,module,created_at)
                        VALUES ('medium','Failed Login Attempt',
                         'Failed login for user: ? from ?','user_activity',?)
                    """, (ua['username'], ua['ip_address'] or 'unknown', now()))

        # 9. Browser extensions
        extensions = collect_browser_extensions()
        c.execute("DELETE FROM browser_extensions")
        for ext in extensions:
            c.execute("""
                INSERT INTO browser_extensions
                (browser,extension_name,extension_id,version,enabled,is_suspicious,collected_at)
                VALUES (:browser,:extension_name,:extension_id,:version,
                 :enabled,:is_suspicious,:collected_at)
            """, ext)

        # 10. Timeline entries
        total_procs   = len(procs)
        suspicious_procs = sum(1 for p in procs if p['risk_level'] in ('high','critical'))
        if suspicious_procs > 0:
            c.execute("""
                INSERT INTO timeline_events (event_type,description,severity,module,created_at)
                VALUES ('threat',?,?,'process',?)
            """, (f"{suspicious_procs} suspicious process(es) detected",
                  "high", now()))

        suspicious_net = sum(1 for n in nets if n['is_suspicious'])
        if suspicious_net > 0:
            c.execute("""
                INSERT INTO timeline_events (event_type,description,severity,module,created_at)
                VALUES ('network',?,?,'network',?)
            """, (f"{suspicious_net} suspicious network connection(s)",
                  "high", now()))

        c.execute("""
            INSERT INTO timeline_events (event_type,description,severity,module,created_at)
            VALUES ('collection','Endpoint data collection completed','info','system',?)
        """, (now(),))

        # 11. AI Risk Analysis
        engine = RiskEngine(db)
        analysis = engine.full_analysis()
        overall_risk = analysis['overall_risk']
        c.execute("UPDATE devices SET risk_score=? WHERE status='online'", (overall_risk,))

        if overall_risk >= 70:
            c.execute("""
                INSERT INTO alerts (severity,title,description,module,created_at)
                VALUES ('critical','High Risk Score Detected',
                 'Endpoint risk score reached ?' || '%' || ' - Immediate investigation required',
                 'ai_risk',?)
            """, (overall_risk, now()))

        # 12. Threat hunting
        hunter = ThreatHunter(db)
        findings = hunter.run_all()
        for f in findings:
            sev = f['severity']
            c.execute("""
                INSERT INTO alerts (severity,title,description,module,created_at)
                VALUES (?,?,?,?,?)
            """, (sev, f['type'], f['description'], 'threat_hunting', f['detected_at']))
            c.execute("""
                INSERT INTO timeline_events (event_type,description,severity,module,raw_data,created_at)
                VALUES ('threat',?,?,?,?,?)
            """, (f['description'], sev, 'threat_hunting',
                  json.dumps({"mitre": f.get("mitre",""), "cmdline": f.get("cmdline","")}),
                  f['detected_at']))

        db.commit()
        db.close()
        print(f"[Collector] Done. Risk: {overall_risk}%, Findings: {len(findings)}")
    except Exception as e:
        print(f"[Collector] Error: {e}")
        import traceback; traceback.print_exc()
    finally:
        collection_running = False

def background_scheduler():
    """Run collection every 60 seconds"""
    while True:
        try:
            run_collection()
        except Exception as e:
            print(f"[Scheduler] Error: {e}")
        time.sleep(60)

# ── App Setup ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    # Initial collection
    t = threading.Thread(target=run_collection, daemon=True)
    t.start()
    # Scheduler
    s = threading.Thread(target=background_scheduler, daemon=True)
    s.start()
    yield

app = FastAPI(title="EndSight-OS API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Helper ────────────────────────────────────────────────
def rows_to_list(rows):
    return [dict(r) for r in rows]

# ── Dashboard ─────────────────────────────────────────────
@app.get("/api/dashboard")
def get_dashboard():
    db = get_db()
    c  = db.cursor()
    device = c.execute("SELECT * FROM devices LIMIT 1").fetchone()
    total_procs     = c.execute("SELECT COUNT(*) FROM processes").fetchone()[0]
    suspicious_procs= c.execute("SELECT COUNT(*) FROM processes WHERE risk_level IN ('high','critical')").fetchone()[0]
    active_net      = c.execute("SELECT COUNT(*) FROM network_connections WHERE state='ESTABLISHED'").fetchone()[0]
    suspicious_net  = c.execute("SELECT COUNT(*) FROM network_connections WHERE is_suspicious=1").fetchone()[0]
    total_alerts    = c.execute("SELECT COUNT(*) FROM alerts WHERE resolved=0").fetchone()[0]
    critical_alerts = c.execute("SELECT COUNT(*) FROM alerts WHERE severity='critical' AND resolved=0").fetchone()[0]
    usb_connected   = c.execute("SELECT COUNT(*) FROM usb_events WHERE event_type='connected'").fetchone()[0]
    unauth_usb      = c.execute("SELECT COUNT(*) FROM usb_events WHERE is_authorized=0 AND event_type='connected'").fetchone()[0]
    recent_alerts   = rows_to_list(c.execute("""
        SELECT * FROM alerts ORDER BY created_at DESC LIMIT 10
    """).fetchall())
    engine   = RiskEngine(db)
    analysis = engine.full_analysis()
    db.close()
    return {
        "device": dict(device) if device else {},
        "stats": {
            "total_processes": total_procs,
            "suspicious_processes": suspicious_procs,
            "active_connections": active_net,
            "suspicious_connections": suspicious_net,
            "open_alerts": total_alerts,
            "critical_alerts": critical_alerts,
            "usb_connected": usb_connected,
            "unauthorized_usb": unauth_usb,
        },
        "risk": analysis,
        "recent_alerts": recent_alerts
    }

# ── Devices ───────────────────────────────────────────────
@app.get("/api/devices")
def get_devices():
    db = get_db()
    rows = db.execute("SELECT * FROM devices").fetchall()
    db.close()
    return rows_to_list(rows)

# ── Processes ─────────────────────────────────────────────
@app.get("/api/processes")
def get_processes():
    db = get_db()
    rows = db.execute("SELECT * FROM processes ORDER BY risk_level DESC, cpu_percent DESC").fetchall()
    db.close()
    return rows_to_list(rows)

@app.get("/api/processes/stats")
def get_process_stats():
    db = get_db()
    c = db.cursor()
    total    = c.execute("SELECT COUNT(*) FROM processes").fetchone()[0]
    critical = c.execute("SELECT COUNT(*) FROM processes WHERE risk_level='critical'").fetchone()[0]
    high     = c.execute("SELECT COUNT(*) FROM processes WHERE risk_level='high'").fetchone()[0]
    medium   = c.execute("SELECT COUNT(*) FROM processes WHERE risk_level='medium'").fetchone()[0]
    low      = c.execute("SELECT COUNT(*) FROM processes WHERE risk_level='low'").fetchone()[0]
    unsigned = c.execute("SELECT COUNT(*) FROM processes WHERE is_signed=0").fetchone()[0]
    hidden   = c.execute("SELECT COUNT(*) FROM processes WHERE is_hidden=1").fetchone()[0]
    db.close()
    return {"total":total,"critical":critical,"high":high,"medium":medium,"low":low,
            "unsigned":unsigned,"hidden":hidden}

# ── Network ───────────────────────────────────────────────
@app.get("/api/network")
def get_network():
    db = get_db()
    rows = db.execute("SELECT * FROM network_connections ORDER BY is_suspicious DESC, collected_at DESC").fetchall()
    db.close()
    return rows_to_list(rows)

@app.get("/api/network/stats")
def get_network_stats():
    db = get_db()
    c = db.cursor()
    total      = c.execute("SELECT COUNT(*) FROM network_connections").fetchone()[0]
    established= c.execute("SELECT COUNT(*) FROM network_connections WHERE state='ESTABLISHED'").fetchone()[0]
    listening  = c.execute("SELECT COUNT(*) FROM network_connections WHERE state='LISTEN'").fetchone()[0]
    suspicious = c.execute("SELECT COUNT(*) FROM network_connections WHERE is_suspicious=1").fetchone()[0]
    db.close()
    return {"total":total,"established":established,"listening":listening,"suspicious":suspicious}

# ── USB ───────────────────────────────────────────────────
@app.get("/api/usb")
def get_usb():
    db = get_db()
    rows = db.execute("SELECT * FROM usb_events ORDER BY last_seen DESC").fetchall()
    db.close()
    return rows_to_list(rows)

@app.post("/api/usb/{serial}/authorize")
def authorize_usb(serial: str):
    db = get_db()
    db.execute("UPDATE usb_events SET is_authorized=1 WHERE serial_number=?", (serial,))
    db.execute("INSERT OR IGNORE INTO authorized_usb (serial_number,added_at,added_by) VALUES (?,?,?)",
               (serial, now(), "admin"))
    db.commit()
    db.close()
    return {"status": "authorized", "serial": serial}

# ── Startup / Persistence ─────────────────────────────────
@app.get("/api/startup")
def get_startup():
    db = get_db()
    rows = db.execute("SELECT * FROM startup_entries ORDER BY is_suspicious DESC, collected_at DESC").fetchall()
    db.close()
    return rows_to_list(rows)

# ── User Activity ─────────────────────────────────────────
@app.get("/api/users")
def get_users():
    db = get_db()
    rows = db.execute("SELECT * FROM user_activity ORDER BY collected_at DESC LIMIT 200").fetchall()
    db.close()
    return rows_to_list(rows)

@app.get("/api/users/stats")
def get_user_stats():
    db = get_db()
    c = db.cursor()
    total   = c.execute("SELECT COUNT(*) FROM user_activity").fetchone()[0]
    failed  = c.execute("SELECT COUNT(*) FROM user_activity WHERE success=0").fetchone()[0]
    rdp     = c.execute("SELECT COUNT(*) FROM user_activity WHERE event_type='rdp_login'").fetchone()[0]
    new_u   = c.execute("SELECT COUNT(*) FROM user_activity WHERE event_type='new_user'").fetchone()[0]
    db.close()
    return {"total":total,"failed_logins":failed,"rdp_sessions":rdp,"new_accounts":new_u}

# ── Software ──────────────────────────────────────────────
@app.get("/api/software")
def get_software():
    db = get_db()
    rows = db.execute("SELECT * FROM software_inventory ORDER BY is_blacklisted DESC, name ASC").fetchall()
    db.close()
    return rows_to_list(rows)

# ── Security Config ───────────────────────────────────────
@app.get("/api/security-config")
def get_security_config():
    db = get_db()
    rows = db.execute("SELECT * FROM security_config ORDER BY item ASC").fetchall()
    db.close()
    return rows_to_list(rows)

# ── File Integrity ────────────────────────────────────────
@app.get("/api/file-integrity")
def get_file_integrity():
    db = get_db()
    rows = db.execute("SELECT * FROM file_integrity ORDER BY detected_at DESC LIMIT 100").fetchall()
    db.close()
    return rows_to_list(rows)

# ── Browser Extensions ────────────────────────────────────
@app.get("/api/browser")
def get_browser():
    db = get_db()
    rows = db.execute("SELECT * FROM browser_extensions ORDER BY is_suspicious DESC").fetchall()
    db.close()
    return rows_to_list(rows)

# ── Alerts ────────────────────────────────────────────────
@app.get("/api/alerts")
def get_alerts(severity: str = None, resolved: int = None):
    db = get_db()
    q = "SELECT * FROM alerts WHERE 1=1"
    params = []
    if severity:
        q += " AND severity=?"; params.append(severity)
    if resolved is not None:
        q += " AND resolved=?"; params.append(resolved)
    q += " ORDER BY created_at DESC LIMIT 500"
    rows = db.execute(q, params).fetchall()
    db.close()
    return rows_to_list(rows)

@app.post("/api/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: int):
    db = get_db()
    db.execute("UPDATE alerts SET resolved=1, resolved_at=? WHERE id=?", (now(), alert_id))
    db.commit()
    db.close()
    return {"status": "resolved"}

@app.get("/api/alerts/stats")
def get_alert_stats():
    db = get_db()
    c = db.cursor()
    total    = c.execute("SELECT COUNT(*) FROM alerts WHERE resolved=0").fetchone()[0]
    critical = c.execute("SELECT COUNT(*) FROM alerts WHERE severity='critical' AND resolved=0").fetchone()[0]
    high     = c.execute("SELECT COUNT(*) FROM alerts WHERE severity='high' AND resolved=0").fetchone()[0]
    medium   = c.execute("SELECT COUNT(*) FROM alerts WHERE severity='medium' AND resolved=0").fetchone()[0]
    low      = c.execute("SELECT COUNT(*) FROM alerts WHERE severity='low' AND resolved=0").fetchone()[0]
    db.close()
    return {"total":total,"critical":critical,"high":high,"medium":medium,"low":low}

# ── AI Risk Engine ────────────────────────────────────────
@app.get("/api/risk")
def get_risk():
    db = get_db()
    engine = RiskEngine(db)
    result = engine.full_analysis()
    db.close()
    return result

# ── Threat Hunting ────────────────────────────────────────
@app.get("/api/threats")
def get_threats():
    db = get_db()
    hunter = ThreatHunter(db)
    findings = hunter.run_all()
    db.close()
    return {"findings": findings, "total": len(findings)}

# ── Timeline ──────────────────────────────────────────────
@app.get("/api/timeline")
def get_timeline():
    db = get_db()
    rows = db.execute("""
        SELECT * FROM timeline_events ORDER BY created_at DESC LIMIT 200
    """).fetchall()
    db.close()
    return rows_to_list(rows)

# ── Reports / Forensics ───────────────────────────────────
@app.get("/api/forensics")
def get_forensics():
    db = get_db()
    c = db.cursor()
    proc_history  = rows_to_list(c.execute("SELECT name,path,risk_level,collected_at FROM processes ORDER BY collected_at DESC LIMIT 50").fetchall())
    usb_history   = rows_to_list(c.execute("SELECT * FROM usb_events ORDER BY last_seen DESC").fetchall())
    login_history = rows_to_list(c.execute("SELECT * FROM user_activity ORDER BY collected_at DESC LIMIT 50").fetchall())
    sw_history    = rows_to_list(c.execute("SELECT name,version,publisher,install_date FROM software_inventory ORDER BY install_date DESC LIMIT 50").fetchall())
    timeline      = rows_to_list(c.execute("SELECT * FROM timeline_events ORDER BY created_at DESC LIMIT 100").fetchall())
    db.close()
    return {
        "process_history": proc_history,
        "usb_history": usb_history,
        "login_history": login_history,
        "software_history": sw_history,
        "timeline": timeline
    }

# ── Settings ──────────────────────────────────────────────
@app.get("/api/settings")
def get_settings():
    db = get_db()
    rows = db.execute("SELECT * FROM settings").fetchall()
    db.close()
    return {r['key']: r['value'] for r in rows}

@app.post("/api/settings")
def update_settings(settings: dict):
    db = get_db()
    for k, v in settings.items():
        db.execute("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)", (k, str(v)))
    db.commit()
    db.close()
    return {"status": "updated"}

# ── Manual Trigger ────────────────────────────────────────
@app.post("/api/collect")
def trigger_collection(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_collection)
    return {"status": "collection started"}

@app.get("/api/health")
def health():
    return {"status": "ok", "time": now(), "version": "1.0.0"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
