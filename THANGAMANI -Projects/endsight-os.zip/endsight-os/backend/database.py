import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "endsight.db")

def get_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hostname TEXT UNIQUE,
        username TEXT,
        os_version TEXT,
        os_build TEXT,
        cpu TEXT,
        cpu_cores INTEGER,
        ram_gb REAL,
        disk_total_gb REAL,
        disk_free_gb REAL,
        bios_vendor TEXT,
        bios_version TEXT,
        ip_address TEXT,
        mac_address TEXT,
        uptime_seconds INTEGER,
        risk_score INTEGER DEFAULT 0,
        last_seen TEXT,
        status TEXT DEFAULT 'online'
    );
    CREATE TABLE IF NOT EXISTS processes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pid INTEGER,
        name TEXT,
        path TEXT,
        cmdline TEXT,
        parent_pid INTEGER,
        parent_name TEXT,
        cpu_percent REAL,
        memory_mb REAL,
        start_time TEXT,
        username TEXT,
        status TEXT,
        is_signed INTEGER DEFAULT 1,
        is_hidden INTEGER DEFAULT 0,
        risk_level TEXT DEFAULT 'low',
        collected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS network_connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        local_address TEXT,
        local_port INTEGER,
        remote_address TEXT,
        remote_port INTEGER,
        protocol TEXT,
        state TEXT,
        pid INTEGER,
        process_name TEXT,
        country TEXT DEFAULT 'Unknown',
        is_suspicious INTEGER DEFAULT 0,
        is_known_bad INTEGER DEFAULT 0,
        collected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS usb_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT,
        vendor TEXT,
        product TEXT,
        serial_number TEXT,
        device_id TEXT,
        size_gb REAL,
        drive_letter TEXT,
        is_authorized INTEGER DEFAULT 0,
        first_seen TEXT,
        last_seen TEXT
    );
    CREATE TABLE IF NOT EXISTS startup_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        path TEXT,
        type TEXT,
        registry_key TEXT,
        command TEXT,
        is_new INTEGER DEFAULT 0,
        is_suspicious INTEGER DEFAULT 0,
        first_seen TEXT,
        collected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS user_activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        event_type TEXT,
        details TEXT,
        ip_address TEXT,
        logon_type TEXT,
        success INTEGER DEFAULT 1,
        event_id INTEGER,
        collected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS software_inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        version TEXT,
        publisher TEXT,
        install_date TEXT,
        install_location TEXT,
        size_mb REAL,
        is_blacklisted INTEGER DEFAULT 0,
        is_unauthorized INTEGER DEFAULT 0,
        collected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS security_config (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item TEXT UNIQUE,
        status TEXT,
        value TEXT,
        details TEXT,
        last_checked TEXT
    );
    CREATE TABLE IF NOT EXISTS file_integrity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT,
        hash_before TEXT,
        hash_after TEXT,
        event_type TEXT,
        size_bytes INTEGER,
        is_suspicious INTEGER DEFAULT 0,
        detected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS browser_extensions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        browser TEXT,
        extension_name TEXT,
        extension_id TEXT,
        version TEXT,
        enabled INTEGER DEFAULT 1,
        is_suspicious INTEGER DEFAULT 0,
        collected_at TEXT
    );
    CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        severity TEXT,
        title TEXT,
        description TEXT,
        module TEXT,
        raw_data TEXT,
        resolved INTEGER DEFAULT 0,
        resolved_at TEXT,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS timeline_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT,
        description TEXT,
        severity TEXT,
        module TEXT,
        raw_data TEXT,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS file_hashes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT UNIQUE,
        hash TEXT,
        size_bytes INTEGER,
        last_verified TEXT
    );
    CREATE TABLE IF NOT EXISTS authorized_usb (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        serial_number TEXT UNIQUE,
        vendor TEXT,
        product TEXT,
        added_at TEXT,
        added_by TEXT
    );
    CREATE TABLE IF NOT EXISTS blacklisted_software (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE,
        reason TEXT
    );
    INSERT OR IGNORE INTO blacklisted_software (name, reason) VALUES
        ('mimikatz','Credential dumping tool'),
        ('pwdump','Password extraction tool'),
        ('metasploit','Penetration testing framework'),
        ('wireshark','Network sniffer'),
        ('netcat','Network tool often abused'),
        ('nmap','Port scanner'),
        ('hacktools','Known hacking tool'),
        ('cain','Password recovery tool'),
        ('aircrack','WiFi cracking tool'),
        ('keylogger','Keylogging software');
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    );
    INSERT OR IGNORE INTO settings (key, value) VALUES
        ('collection_interval_seconds','60'),
        ('alert_email',''),
        ('webhook_url',''),
        ('monitor_paths','C:\\Windows\\System32'),
        ('threat_hunting_enabled','1'),
        ('usb_block_unauthorized','0');
    """)
    conn.commit()
    conn.close()
    print("[DB] Initialized successfully")
