"""
Threat Hunting Engine
Automatically searches for known attack patterns and TTPs
"""
import datetime

def now():
    return datetime.datetime.now().isoformat()

class ThreatHunter:
    def __init__(self, db_conn):
        self.db = db_conn

    def _q(self, sql, params=()):
        return self.db.execute(sql, params).fetchall()

    def hunt_lolbin_abuse(self):
        findings = []
        rows = self._q("""
            SELECT name, parent_name, cmdline, pid FROM processes
            WHERE LOWER(name) IN ('powershell.exe','cmd.exe','wscript.exe',
                                  'cscript.exe','mshta.exe','rundll32.exe',
                                  'regsvr32.exe','certutil.exe','bitsadmin.exe')
              AND LOWER(parent_name) IN ('winword.exe','excel.exe','outlook.exe',
                                         'powerpnt.exe','onenote.exe','msaccess.exe')
        """)
        for r in rows:
            findings.append({
                "type": "LOLBin Abuse",
                "severity": "critical",
                "description": f"{r['name']} spawned by {r['parent_name']} (PID:{r['pid']}) - Office macro abuse suspected",
                "cmdline": r['cmdline'] or "",
                "mitre": "T1059 - Command and Scripting Interpreter",
                "detected_at": now()
            })
        return findings

    def hunt_encoded_commands(self):
        findings = []
        rows = self._q("""
            SELECT name, cmdline, pid FROM processes
            WHERE (LOWER(cmdline) LIKE '%-enc %' OR LOWER(cmdline) LIKE '%-encodedcommand%'
               OR LOWER(cmdline) LIKE '%-e %JAB%' OR LOWER(cmdline) LIKE '%base64%')
              AND name IS NOT NULL
        """)
        for r in rows:
            findings.append({
                "type": "Encoded Command Execution",
                "severity": "high",
                "description": f"{r['name']} (PID:{r['pid']}) executed with encoded/obfuscated command",
                "cmdline": (r['cmdline'] or "")[:200],
                "mitre": "T1027 - Obfuscated Files or Information",
                "detected_at": now()
            })
        return findings

    def hunt_suspicious_parent_child(self):
        findings = []
        # Explorer spawning cmd/powershell directly - unusual
        rows = self._q("""
            SELECT name, parent_name, cmdline, pid FROM processes
            WHERE LOWER(name) IN ('cmd.exe','powershell.exe')
              AND LOWER(parent_name) IN ('explorer.exe')
              AND (LOWER(cmdline) LIKE '%/c %' OR LOWER(cmdline) LIKE '%-command%'
                OR LOWER(cmdline) LIKE '%-c %')
        """)
        for r in rows:
            findings.append({
                "type": "Suspicious Parent-Child Process",
                "severity": "medium",
                "description": f"Explorer spawned {r['name']} with command args (PID:{r['pid']})",
                "cmdline": (r['cmdline'] or "")[:200],
                "mitre": "T1059 - Command and Scripting Interpreter",
                "detected_at": now()
            })
        return findings

    def hunt_persistence_techniques(self):
        findings = []
        # Suspicious registry entries
        rows = self._q("""
            SELECT name, path, command, type FROM startup_entries
            WHERE is_suspicious=1
        """)
        for r in rows:
            stype = "Registry Run Key" if r['type'] == 'registry' else "Scheduled Task"
            findings.append({
                "type": f"Persistence via {stype}",
                "severity": "high",
                "description": f"Suspicious {stype}: '{r['name']}' → {r['path'] or r['command'] or 'unknown'}",
                "cmdline": r['command'] or "",
                "mitre": "T1547 - Boot or Logon Autostart Execution",
                "detected_at": now()
            })
        return findings

    def hunt_c2_indicators(self):
        findings = []
        c2_ports = [4444, 1337, 31337, 8888, 9999, 6666, 6667, 1234, 12345]
        port_list = ','.join(str(p) for p in c2_ports)
        rows = self._q(f"""
            SELECT remote_address, remote_port, process_name, pid FROM network_connections
            WHERE remote_port IN ({port_list}) AND remote_address!='' AND state='ESTABLISHED'
        """)
        for r in rows:
            findings.append({
                "type": "C2 Communication Indicator",
                "severity": "critical",
                "description": f"{r['process_name']} (PID:{r['pid']}) connected to {r['remote_address']}:{r['remote_port']} (known C2 port)",
                "cmdline": "",
                "mitre": "T1071 - Application Layer Protocol",
                "detected_at": now()
            })
        return findings

    def hunt_credential_access(self):
        findings = []
        # Multiple failed logins
        rows = self._q("""
            SELECT username, COUNT(*) as cnt FROM user_activity
            WHERE success=0
            GROUP BY username HAVING cnt >= 5
        """)
        for r in rows:
            findings.append({
                "type": "Credential Brute Force",
                "severity": "high",
                "description": f"Account '{r['username']}' had {r['cnt']} failed login attempts",
                "cmdline": "",
                "mitre": "T1110 - Brute Force",
                "detected_at": now()
            })
        # New accounts created
        rows = self._q("""
            SELECT username, collected_at FROM user_activity
            WHERE event_type='new_user'
        """)
        for r in rows:
            findings.append({
                "type": "New User Account Created",
                "severity": "medium",
                "description": f"New account created: '{r['username']}' at {r['collected_at']}",
                "cmdline": "",
                "mitre": "T1136 - Create Account",
                "detected_at": now()
            })
        return findings

    def hunt_ransomware_indicators(self):
        findings = []
        # Mass file modifications in short time - check file_integrity
        rows = self._q("""
            SELECT COUNT(*) as cnt, MAX(detected_at) as last_seen FROM file_integrity
            WHERE event_type='modified' AND is_suspicious=1
        """)
        for r in rows:
            if r['cnt'] and r['cnt'] > 10:
                findings.append({
                    "type": "Ransomware Indicator",
                    "severity": "critical",
                    "description": f"{r['cnt']} critical system file modifications detected - potential ransomware activity",
                    "cmdline": "",
                    "mitre": "T1486 - Data Encrypted for Impact",
                    "detected_at": r['last_seen'] or now()
                })
        # Certutil being used (common for payload download)
        rows = self._q("""
            SELECT name, cmdline, pid FROM processes
            WHERE LOWER(name)='certutil.exe'
              AND (LOWER(cmdline) LIKE '%-decode%' OR LOWER(cmdline) LIKE '%-urlcache%')
        """)
        for r in rows:
            findings.append({
                "type": "Certutil Payload Download",
                "severity": "critical",
                "description": f"certutil.exe (PID:{r['pid']}) used for file download/decode - LOLBin abuse",
                "cmdline": (r['cmdline'] or "")[:200],
                "mitre": "T1105 - Ingress Tool Transfer",
                "detected_at": now()
            })
        return findings

    def hunt_insider_threat(self):
        findings = []
        # Off-hours access
        rows = self._q("""
            SELECT username, collected_at FROM user_activity
            WHERE event_type='login' AND success=1
              AND (CAST(strftime('%H',collected_at) AS INTEGER)<6
                OR CAST(strftime('%H',collected_at) AS INTEGER)>23)
        """)
        for r in rows:
            findings.append({
                "type": "Off-Hours Access",
                "severity": "medium",
                "description": f"User '{r['username']}' logged in during off-hours: {r['collected_at']}",
                "cmdline": "",
                "mitre": "T1078 - Valid Accounts",
                "detected_at": now()
            })
        # Unauthorized USB
        rows = self._q("""
            SELECT vendor, product, serial_number FROM usb_events
            WHERE is_authorized=0 AND event_type='connected'
        """)
        for r in rows:
            findings.append({
                "type": "Unauthorized USB Device",
                "severity": "high",
                "description": f"Unauthorized USB: {r['vendor']} {r['product']} (S/N:{r['serial_number']})",
                "cmdline": "",
                "mitre": "T1052 - Exfiltration Over Physical Medium",
                "detected_at": now()
            })
        return findings

    def run_all(self):
        all_findings = []
        all_findings += self.hunt_lolbin_abuse()
        all_findings += self.hunt_encoded_commands()
        all_findings += self.hunt_suspicious_parent_child()
        all_findings += self.hunt_persistence_techniques()
        all_findings += self.hunt_c2_indicators()
        all_findings += self.hunt_credential_access()
        all_findings += self.hunt_ransomware_indicators()
        all_findings += self.hunt_insider_threat()
        return all_findings
