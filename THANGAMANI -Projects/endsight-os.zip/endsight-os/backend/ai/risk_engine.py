"""
AI Risk Engine - Multi-factor endpoint risk scoring
Real weighted scoring with anomaly detection patterns
"""
import datetime

def now():
    return datetime.datetime.now().isoformat()

KNOWN_MALICIOUS_PORTS = {4444,1337,31337,8888,9999,6666,6667,1234,12345,4445,5555}

class RiskEngine:
    def __init__(self, db_conn):
        self.db = db_conn

    def _q(self, sql, params=()):
        return self.db.execute(sql, params).fetchall()

    def _q1(self, sql, params=()):
        row = self.db.execute(sql, params).fetchone()
        return row[0] if row else 0

    def calc_process_risk(self):
        score = 0; reasons = []
        unsigned      = self._q1("SELECT COUNT(*) FROM processes WHERE is_signed=0 AND name!=''")
        hidden        = self._q1("SELECT COUNT(*) FROM processes WHERE is_hidden=1")
        critical_procs= self._q1("SELECT COUNT(*) FROM processes WHERE risk_level='critical'")
        high_procs    = self._q1("SELECT COUNT(*) FROM processes WHERE risk_level='high'")
        lolbin_chain  = self._q1("""
            SELECT COUNT(*) FROM processes
            WHERE LOWER(name) IN ('powershell.exe','cmd.exe','wscript.exe','mshta.exe')
              AND LOWER(parent_name) IN ('powershell.exe','cmd.exe','word.exe','excel.exe','outlook.exe')
        """)
        temp_procs = self._q1("""
            SELECT COUNT(*) FROM processes
            WHERE LOWER(path) LIKE '%\\temp\\%'
               OR LOWER(path) LIKE '%\\tmp\\%'
               OR LOWER(path) LIKE '%\\users\\public\\%'
        """)
        score += min(40, unsigned * 8)
        score += min(30, hidden * 15)
        score += min(30, critical_procs * 15)
        score += min(20, high_procs * 5)
        score += min(25, lolbin_chain * 12)
        score += min(20, temp_procs * 10)
        if unsigned > 0:       reasons.append(f"{unsigned} Unsigned Executable(s) Running")
        if hidden > 0:         reasons.append(f"{hidden} Hidden Process(es) Detected")
        if critical_procs > 0: reasons.append(f"{critical_procs} Critical Risk Process(es)")
        if lolbin_chain > 0:   reasons.append("Suspicious LOLBin Parent-Child Chain Detected")
        if temp_procs > 0:     reasons.append(f"{temp_procs} Process(es) Running from Temp Dir")
        return min(100, score), reasons

    def calc_network_risk(self):
        score = 0; reasons = []
        suspicious = self._q1("SELECT COUNT(*) FROM network_connections WHERE is_suspicious=1")
        known_bad  = self._q1("SELECT COUNT(*) FROM network_connections WHERE is_known_bad=1")
        port_list  = ','.join(str(p) for p in KNOWN_MALICIOUS_PORTS)
        c2_ports   = self._q1(f"""
            SELECT COUNT(*) FROM network_connections
            WHERE remote_port IN ({port_list}) AND remote_address!=''
        """)
        rdp_exposed = self._q1("""
            SELECT COUNT(*) FROM network_connections
            WHERE local_port=3389 AND state='LISTEN'
        """)
        score += min(50, suspicious * 20)
        score += min(40, known_bad * 30)
        score += min(35, c2_ports * 25)
        score += min(15, rdp_exposed * 10)
        if suspicious > 0:  reasons.append(f"{suspicious} Suspicious Network Connection(s)")
        if known_bad > 0:   reasons.append(f"{known_bad} Connection(s) to Known Bad IPs")
        if c2_ports > 0:    reasons.append("C2 Communication Port Detected")
        if rdp_exposed > 0: reasons.append("RDP Port 3389 Exposed")
        return min(100, score), reasons

    def calc_usb_risk(self):
        score = 0; reasons = []
        unauth = self._q1("SELECT COUNT(*) FROM usb_events WHERE is_authorized=0 AND event_type='connected'")
        total  = self._q1("SELECT COUNT(*) FROM usb_events WHERE event_type='connected'")
        score += min(80, unauth * 40)
        if total > 3: score += min(20, (total-3)*5); reasons.append(f"High USB Activity: {total} devices")
        if unauth > 0: reasons.append(f"{unauth} Unauthorized USB Device(s)")
        return min(100, score), reasons

    def calc_persistence_risk(self):
        score = 0; reasons = []
        suspicious  = self._q1("SELECT COUNT(*) FROM startup_entries WHERE is_suspicious=1")
        new_entries = self._q1("SELECT COUNT(*) FROM startup_entries WHERE is_new=1")
        sched       = self._q1("SELECT COUNT(*) FROM startup_entries WHERE type='scheduled_task' AND is_suspicious=1")
        score += min(60, suspicious * 25)
        score += min(30, new_entries * 10)
        score += min(40, sched * 20)
        if suspicious > 0:  reasons.append(f"{suspicious} Suspicious Persistence Entry(ies)")
        if new_entries > 0: reasons.append(f"{new_entries} New Startup Entry(ies) Detected")
        if sched > 0:       reasons.append(f"{sched} Suspicious Scheduled Task(s)")
        return min(100, score), reasons

    def calc_user_risk(self):
        score = 0; reasons = []
        failed    = self._q1("SELECT COUNT(*) FROM user_activity WHERE success=0")
        new_users = self._q1("SELECT COUNT(*) FROM user_activity WHERE event_type='new_user'")
        rdp       = self._q1("SELECT COUNT(*) FROM user_activity WHERE event_type='rdp_login'")
        off_hours = self._q1("""
            SELECT COUNT(*) FROM user_activity
            WHERE event_type='login' AND success=1
              AND (CAST(strftime('%H',collected_at) AS INTEGER)<7
                OR CAST(strftime('%H',collected_at) AS INTEGER)>22)
        """)
        brute = self._q1("""
            SELECT COUNT(*) FROM (
                SELECT ip_address,COUNT(*) c FROM user_activity
                WHERE success=0 AND ip_address!=''
                GROUP BY ip_address HAVING c>=5
            )
        """)
        score += min(40, failed * 8)
        score += min(30, new_users * 15)
        score += min(20, rdp * 5)
        score += min(20, off_hours * 8)
        score += min(40, brute * 40)
        if failed >= 5:   reasons.append(f"{failed} Failed Login Attempt(s)")
        if new_users > 0: reasons.append(f"{new_users} New User Account(s) Created")
        if rdp > 0:       reasons.append(f"{rdp} Remote Desktop Session(s)")
        if brute > 0:     reasons.append("Brute Force Attack Pattern Detected")
        if off_hours > 0: reasons.append(f"Off-Hours Login Activity ({off_hours})")
        return min(100, score), reasons

    def calc_software_risk(self):
        score = 0; reasons = []
        blacklisted  = self._q1("SELECT COUNT(*) FROM software_inventory WHERE is_blacklisted=1")
        unauthorized = self._q1("SELECT COUNT(*) FROM software_inventory WHERE is_unauthorized=1")
        score += min(80, blacklisted * 40)
        score += min(30, unauthorized * 10)
        if blacklisted > 0:  reasons.append(f"{blacklisted} Blacklisted Tool(s) Installed")
        if unauthorized > 0: reasons.append(f"{unauthorized} Unauthorized Software")
        return min(100, score), reasons

    def calc_config_risk(self):
        score = 0; reasons = []
        disabled = self._q("SELECT item FROM security_config WHERE status='disabled'")
        for row in disabled:
            item = row[0]
            if "Defender" in item or "Firewall" in item:
                score += 25; reasons.append(f"{item} is DISABLED")
            elif "BitLocker" in item:
                score += 15; reasons.append(f"{item} not enabled")
            elif "UAC" in item:
                score += 20; reasons.append(f"{item} DISABLED - Privilege Escalation Risk")
            else:
                score += 10; reasons.append(f"{item} misconfigured")
        return min(100, score), reasons

    def full_analysis(self):
        proc_score,  proc_r  = self.calc_process_risk()
        net_score,   net_r   = self.calc_network_risk()
        usb_score,   usb_r   = self.calc_usb_risk()
        pers_score,  pers_r  = self.calc_persistence_risk()
        user_score,  user_r  = self.calc_user_risk()
        sw_score,    sw_r    = self.calc_software_risk()
        cfg_score,   cfg_r   = self.calc_config_risk()

        weights = {
            "process":     (proc_score,  0.25),
            "network":     (net_score,   0.20),
            "usb":         (usb_score,   0.10),
            "persistence": (pers_score,  0.20),
            "user":        (user_score,  0.15),
            "software":    (sw_score,    0.05),
            "config":      (cfg_score,   0.05),
        }
        overall = int(sum(s * w for s, w in weights.values()))
        all_reasons = proc_r + net_r + usb_r + pers_r + user_r + sw_r + cfg_r

        # Threat classification
        threats = []
        if proc_score > 50 or sw_score > 40:
            threats.append({"type":"Malware Activity","probability":min(95,proc_score+10),"color":"red"})
        if pers_score > 30:
            threats.append({"type":"Persistence / Rootkit","probability":min(95,pers_score+5),"color":"red"})
        if net_score > 30:
            threats.append({"type":"C2 Communication","probability":min(90,net_score),"color":"orange"})
        if user_score > 40:
            threats.append({"type":"Credential Abuse / Brute Force","probability":min(90,user_score),"color":"orange"})
        if usb_score > 20:
            threats.append({"type":"USB-Based Attack Vector","probability":min(85,usb_score+10),"color":"yellow"})
        if proc_score > 30 and user_score > 20:
            threats.append({"type":"Insider Threat","probability":min(80,(proc_score+user_score)//2),"color":"yellow"})
        if not threats:
            threats.append({"type":"Low Risk - Normal Activity","probability":10,"color":"green"})

        # Recommendations
        recs = []
        if proc_score > 30:
            recs.append({"issue":"Suspicious Processes","action":"Terminate unsigned/hidden processes and investigate their origin"})
        if net_score > 20:
            recs.append({"issue":"Suspicious Connections","action":"Block suspicious IPs via Windows Firewall"})
        if usb_score > 0:
            recs.append({"issue":"Unauthorized USB","action":"Implement USB whitelist via Group Policy"})
        if pers_score > 20:
            recs.append({"issue":"Persistence Mechanisms","action":"Remove suspicious startup entries and audit scheduled tasks"})
        if user_score > 30:
            recs.append({"issue":"Account Security","action":"Enable account lockout policy, investigate failed login sources"})
        if cfg_score > 0:
            recs.append({"issue":"Security Configuration","action":"Enable Defender, Firewall, UAC, BitLocker immediately"})

        return {
            "overall_risk": overall,
            "process_risk": proc_score,
            "network_risk": net_score,
            "usb_risk": usb_score,
            "persistence_risk": pers_score,
            "user_risk": user_score,
            "software_risk": sw_score,
            "config_risk": cfg_score,
            "risk_reasons": all_reasons,
            "threat_classification": threats,
            "recommendations": recs,
            "attack_probability": min(98, overall + 8),
            "compromise_probability": max(0, min(95, overall - 5)),
            "analyzed_at": now()
        }
