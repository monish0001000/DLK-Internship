#!/bin/bash
echo ""
echo "🛡  EndSight-OS - AI Endpoint Security Platform"
echo "================================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 not found. Install: sudo apt install python3 python3-pip"
    exit 1
fi
echo "[OK] Python3 found"

# Check Node
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js not found. Install from https://nodejs.org/"
    exit 1
fi
echo "[OK] Node.js found"

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "[1/4] Installing Python dependencies..."
cd "$DIR/backend"
pip3 install -r requirements.txt -q
echo "[OK] Python packages installed"

echo ""
echo "[2/4] Installing Node.js dependencies..."
cd "$DIR/frontend"
npm install --silent
echo "[OK] Node packages installed"

echo ""
echo "[3/4] Starting Backend..."
cd "$DIR/backend"
python3 main.py &
BACKEND_PID=$!
sleep 3

echo ""
echo "[4/4] Starting Frontend..."
cd "$DIR/frontend"
npm run dev &
FRONTEND_PID=$!
sleep 3

echo ""
echo "========================================="
echo " EndSight-OS is RUNNING!"
echo "========================================="
echo " Dashboard: http://localhost:3000"
echo " API:       http://localhost:8000"
echo " API Docs:  http://localhost:8000/docs"
echo ""
echo " Press Ctrl+C to stop all services"
echo ""

# Open browser
if command -v xdg-open &> /dev/null; then
    sleep 2 && xdg-open http://localhost:3000 &
elif command -v open &> /dev/null; then
    sleep 2 && open http://localhost:3000 &
fi

trap "echo ''; echo 'Stopping...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit" SIGINT SIGTERM
wait
