@echo off
title EndSight-OS Startup
color 0A
echo.
echo  ███████╗███╗   ██╗██████╗ ███████╗██╗ ██████╗ ██╗  ██╗████████╗       ██████╗ ███████╗
echo  ██╔════╝████╗  ██║██╔══██╗██╔════╝██║██╔════╝ ██║  ██║╚══██╔══╝      ██╔═══██╗██╔════╝
echo  █████╗  ██╔██╗ ██║██║  ██║███████╗██║██║  ███╗███████║   ██║   █████╗██║   ██║███████╗
echo  ██╔══╝  ██║╚██╗██║██║  ██║╚════██║██║██║   ██║██╔══██║   ██║   ╚════╝██║   ██║╚════██║
echo  ███████╗██║ ╚████║██████╔╝███████║██║╚██████╔╝██║  ██║   ██║         ╚██████╔╝███████║
echo  ╚══════╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝          ╚═════╝ ╚══════╝
echo.
echo  AI-Powered Endpoint Security Platform
echo  ========================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.9+ from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)
echo [OK] Python found

:: Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js not found!
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)
echo [OK] Node.js found

echo.
echo [1/4] Installing Python dependencies...
cd /d "%~dp0backend"
pip install -r requirements.txt -q --disable-pip-version-check
if errorlevel 1 (
    echo [ERROR] Failed to install Python packages
    pause
    exit /b 1
)
echo [OK] Python packages installed

echo.
echo [2/4] Installing Node.js dependencies...
cd /d "%~dp0frontend"
call npm install --silent
if errorlevel 1 (
    echo [ERROR] Failed to install Node packages
    pause
    exit /b 1
)
echo [OK] Node packages installed

echo.
echo [3/4] Starting Python Backend (port 8000)...
cd /d "%~dp0backend"
start "EndSight-OS Backend" /min cmd /c "python main.py & pause"
timeout /t 3 /nobreak >nul

echo.
echo [4/4] Starting React Frontend (port 3000)...
cd /d "%~dp0frontend"
start "EndSight-OS Frontend" /min cmd /c "npm run dev & pause"
timeout /t 4 /nobreak >nul

echo.
echo  =========================================
echo   EndSight-OS is RUNNING!
echo  =========================================
echo.
echo   Dashboard : http://localhost:3000
echo   API       : http://localhost:8000
echo   API Docs  : http://localhost:8000/docs
echo.
echo   Opening dashboard in browser...
timeout /t 2 /nobreak >nul
start http://localhost:3000

echo.
echo   Press any key to STOP all services...
pause >nul

echo.
echo  Stopping services...
taskkill /f /fi "WINDOWTITLE eq EndSight-OS Backend*" >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq EndSight-OS Frontend*" >nul 2>&1
taskkill /f /im "python.exe" /fi "WINDOWTITLE eq EndSight*" >nul 2>&1
echo  Done. Goodbye!
timeout /t 2 /nobreak >nul
