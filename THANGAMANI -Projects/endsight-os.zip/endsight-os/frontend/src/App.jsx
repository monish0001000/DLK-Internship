import { useState, useEffect, useCallback } from 'react'
import {
  Shield, Monitor, Activity, Wifi, Usb, Play, Users,
  Package, Lock, FileSearch, Globe, Target, Bell,
  LayoutDashboard, Clock, BarChart2, Settings, RefreshCw,
  AlertTriangle, CheckCircle, XCircle, ChevronRight,
  Cpu, HardDrive, MemoryStick, Server, Eye, Zap, TrendingUp
} from 'lucide-react'
import { RadialBarChart, RadialBar, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from 'recharts'

const API = ''

function useApi(endpoint, interval = null) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(`${API}${endpoint}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
      setError(null)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [endpoint])

  useEffect(() => {
    fetchData()
    if (interval) {
      const t = setInterval(fetchData, interval)
      return () => clearInterval(t)
    }
  }, [fetchData, interval])

  return { data, loading, error, refetch: fetchData }
}

function riskColor(score) {
  if (score >= 70) return '#ef4444'
  if (score >= 40) return '#f97316'
  if (score >= 20) return '#f59e0b'
  return '#10b981'
}

function riskLabel(score) {
  if (score >= 70) return 'CRITICAL'
  if (score >= 40) return 'HIGH'
  if (score >= 20) return 'MEDIUM'
  return 'LOW'
}

function Badge({ sev }) {
  const s = (sev || '').toLowerCase()
  return <span className={`badge badge-${s}`}>{sev?.toUpperCase()}</span>
}

function Loading() {
  return <div className="loading"><div className="spinner" /><span>Loading data...</span></div>
}

function Empty({ msg = 'No data found' }) {
  return <div className="empty"><Shield size={40} /><p>{msg}</p></div>
}

function RiskGauge({ score, size = 120 }) {
  const color = riskColor(score)
  const r = (size - 16) / 2
  const circ = 2 * Math.PI * r
  const fill = circ - (score / 100) * circ
  return (
    <div className="risk-ring" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1e2d4a" strokeWidth={8} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={8}
          strokeDasharray={circ} strokeDashoffset={fill} strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.8s ease' }} />
      </svg>
      <div className="risk-center">
        <div className="risk-pct" style={{ color }}>{score}%</div>
        <div className="risk-lbl" style={{ color }}>{riskLabel(score)}</div>
      </div>
    </div>
  )
}

function ProgressBar({ value, max = 100, color }) {
  const pct = Math.min(100, (value / max) * 100)
  const c = color || riskColor(pct)
  return (
    <div className="progress-bar">
      <div className="progress-fill" style={{ width: `${pct}%`, background: c }} />
    </div>
  )
}

function formatTime(ts) {
  if (!ts) return '-'
  try {
    const d = new Date(ts)
    return d.toLocaleString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
  } catch { return ts }
}

// ── DASHBOARD ─────────────────────────────────────────────
function Dashboard({ onAlert }) {
  const { data, loading, refetch } = useApi('/api/dashboard', 30000)
  const [collecting, setCollecting] = useState(false)

  async function triggerCollect() {
    setCollecting(true)
    await fetch('/api/collect', { method: 'POST' })
    setTimeout(() => { setCollecting(false); refetch() }, 3000)
  }

  if (loading) return <div className="page"><Loading /></div>
  if (!data) return <div className="page"><Empty msg="Backend not connected. Make sure Python backend is running on port 8000." /></div>

  const { device, stats, risk, recent_alerts } = data

  const statCards = [
    { label: 'Total Processes', value: stats.total_processes, sub: `${stats.suspicious_processes} suspicious`, color: stats.suspicious_processes > 0 ? 'var(--orange)' : 'var(--green)', icon: <Activity size={18} /> },
    { label: 'Network Connections', value: stats.active_connections, sub: `${stats.suspicious_connections} suspicious`, color: stats.suspicious_connections > 0 ? 'var(--red)' : 'var(--accent)', icon: <Wifi size={18} /> },
    { label: 'Open Alerts', value: stats.open_alerts, sub: `${stats.critical_alerts} critical`, color: stats.critical_alerts > 0 ? 'var(--red)' : 'var(--text-mid)', icon: <Bell size={18} /> },
    { label: 'USB Devices', value: stats.usb_connected, sub: `${stats.unauthorized_usb} unauthorized`, color: stats.unauthorized_usb > 0 ? 'var(--orange)' : 'var(--green)', icon: <Usb size={18} /> },
  ]

  const riskBars = [
    { label: 'Process Risk', val: risk.process_risk },
    { label: 'Network Risk', val: risk.network_risk },
    { label: 'User Risk', val: risk.user_risk },
    { label: 'Persistence Risk', val: risk.persistence_risk },
    { label: 'USB Risk', val: risk.usb_risk },
    { label: 'Software Risk', val: risk.software_risk },
    { label: 'Config Risk', val: risk.config_risk },
  ]

  return (
    <div className="page">
      {/* Top bar */}
      <div className="flex-between mb-24">
        <div>
          <h2 style={{ fontSize: 20, fontWeight: 700 }}>Security Dashboard</h2>
          <p className="text-dim" style={{ fontSize: 12, marginTop: 2 }}>
            {device?.hostname || 'Unknown Host'} • {device?.ip_address || ''} • {device?.os_build || ''} {device?.os_version || ''}
          </p>
        </div>
        <button className="btn btn-primary" onClick={triggerCollect} disabled={collecting}>
          <RefreshCw size={14} className={collecting ? 'spinner' : ''} />
          {collecting ? 'Collecting...' : 'Refresh Now'}
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid-4 mb-20">
        {statCards.map((s, i) => (
          <div className="card stat-card" key={i}>
            <div className="flex-between">
              <span className="stat-label">{s.label}</span>
              <span style={{ color: 'var(--text-dim)' }}>{s.icon}</span>
            </div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-sub">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Risk + Alerts */}
      <div className="grid-2 mb-20">
        {/* AI Risk */}
        <div className="card">
          <div className="card-title">AI Risk Engine</div>
          <div className="flex-center gap-20" style={{ marginBottom: 20 }}>
            <RiskGauge score={risk.overall_risk} size={130} />
            <div style={{ flex: 1 }}>
              <div style={{ marginBottom: 8 }}>
                <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>Attack Probability</span>
                <div style={{ fontSize: 18, fontWeight: 700, color: riskColor(risk.attack_probability) }}>{risk.attack_probability}%</div>
              </div>
              <div>
                <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>Compromise Risk</span>
                <div style={{ fontSize: 18, fontWeight: 700, color: riskColor(risk.compromise_probability) }}>{risk.compromise_probability}%</div>
              </div>
            </div>
          </div>
          {riskBars.map((rb, i) => (
            <div className="risk-row" key={i}>
              <span className="risk-label">{rb.label}</span>
              <div className="risk-bar"><ProgressBar value={rb.val} /></div>
              <span className="risk-value" style={{ color: riskColor(rb.val) }}>{rb.val}%</span>
            </div>
          ))}
        </div>

        {/* Alerts */}
        <div className="card">
          <div className="card-title flex-between">
            <span>Recent Alerts</span>
            <button className="btn btn-outline" style={{ fontSize: 11, padding: '4px 10px' }} onClick={() => onAlert()}>View All</button>
          </div>
          {(!recent_alerts || recent_alerts.length === 0)
            ? <Empty msg="No alerts — system looks clean!" />
            : recent_alerts.slice(0, 8).map((a, i) => (
              <div className="alert-item" key={i}>
                <div className={`alert-dot ${a.severity}`} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="alert-title">{a.title}</div>
                  <div className="alert-desc">{a.description?.slice(0, 80)}{a.description?.length > 80 ? '…' : ''}</div>
                  <div className="alert-time">{formatTime(a.created_at)}</div>
                </div>
                <Badge sev={a.severity} />
              </div>
            ))
          }
        </div>
      </div>

      {/* Threat Classification + Device Health */}
      <div className="grid-2">
        <div className="card">
          <div className="card-title">AI Threat Classification</div>
          {risk.threat_classification?.map((t, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div className="flex-between" style={{ marginBottom: 6 }}>
                <span style={{ fontSize: 13 }}>{t.type}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: riskColor(t.probability) }}>{t.probability}%</span>
              </div>
              <ProgressBar value={t.probability} color={riskColor(t.probability)} />
            </div>
          ))}
        </div>

        <div className="card">
          <div className="card-title">AI Recommendations</div>
          {(!risk.recommendations || risk.recommendations.length === 0)
            ? <div className="flex-center gap-8" style={{ color: 'var(--green)', padding: '20px 0' }}>
                <CheckCircle size={18} /> <span>No recommendations — system is well-configured!</span>
              </div>
            : risk.recommendations?.map((r, i) => (
              <div key={i} style={{ padding: '10px 0', borderBottom: '1px solid rgba(30,45,74,0.5)' }}>
                <div className="flex-center gap-8" style={{ marginBottom: 4 }}>
                  <AlertTriangle size={14} style={{ color: 'var(--yellow)', flexShrink: 0 }} />
                  <span style={{ fontWeight: 600, fontSize: 13 }}>{r.issue}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-dim)', paddingLeft: 22 }}>{r.action}</div>
              </div>
            ))
          }
        </div>
      </div>

      {/* Risk reasons */}
      {risk.risk_reasons?.length > 0 && (
        <div className="card" style={{ marginTop: 20 }}>
          <div className="card-title">Risk Factors Detected</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {risk.risk_reasons.map((r, i) => (
              <span key={i} style={{ background: 'rgba(239,68,68,0.1)', color: 'var(--red-bright)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 6, padding: '4px 10px', fontSize: 12 }}>{r}</span>
            ))}
          </div>
        </div>
      )}

      {/* Device info */}
      {device && (
        <div className="card" style={{ marginTop: 20 }}>
          <div className="card-title">Device Information</div>
          <div className="grid-4">
            {[
              { icon: <Server size={14} />, label: 'Hostname', val: device.hostname },
              { icon: <Cpu size={14} />, label: 'CPU', val: `${device.cpu?.slice(0,30)} (${device.cpu_cores} cores)` },
              { icon: <MemoryStick size={14} />, label: 'RAM', val: `${device.ram_gb} GB` },
              { icon: <HardDrive size={14} />, label: 'Disk', val: `${device.disk_free_gb}GB free / ${device.disk_total_gb}GB` },
            ].map((item, i) => (
              <div key={i}>
                <div className="flex-center gap-8 text-dim" style={{ marginBottom: 4, fontSize: 11 }}>{item.icon} {item.label}</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{item.val || '-'}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── PROCESSES ─────────────────────────────────────────────
function Processes() {
  const { data: procs, loading } = useApi('/api/processes', 15000)
  const { data: stats } = useApi('/api/processes/stats')
  const [filter, setFilter] = useState('')
  const [riskFilter, setRiskFilter] = useState('all')

  const filtered = (procs || []).filter(p => {
    const q = filter.toLowerCase()
    const matchQ = !q || p.name?.toLowerCase().includes(q) || p.path?.toLowerCase().includes(q) || String(p.pid).includes(q)
    const matchR = riskFilter === 'all' || p.risk_level === riskFilter
    return matchQ && matchR
  })

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Live Process Monitor</h2>
        <div className="flex-center gap-8">
          <input className="search-box" placeholder="Search by name, PID, path…" value={filter} onChange={e => setFilter(e.target.value)} />
          <select value={riskFilter} onChange={e => setRiskFilter(e.target.value)} style={{ background: 'var(--bg-hover)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: 6, padding: '7px 10px', fontSize: 13 }}>
            <option value="all">All Risk</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {stats && (
        <div className="grid-4 mb-20">
          {[
            { label: 'Total', val: stats.total, color: 'var(--accent)' },
            { label: 'Critical', val: stats.critical, color: 'var(--red)' },
            { label: 'High Risk', val: stats.high, color: 'var(--orange)' },
            { label: 'Unsigned', val: stats.unsigned, color: 'var(--yellow)' },
          ].map((s, i) => (
            <div className="card stat-card" key={i}>
              <div className="stat-label">{s.label}</div>
              <div className="stat-value" style={{ color: s.color }}>{s.val ?? 0}</div>
            </div>
          ))}
        </div>
      )}

      <div className="card">
        {loading ? <Loading /> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>PID</th><th>Name</th><th>Parent</th><th>CPU%</th>
                  <th>Memory</th><th>User</th><th>Status</th><th>Risk</th><th>Signed</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 200).map((p, i) => (
                  <tr key={i}>
                    <td className="font-mono" style={{ color: 'var(--accent)' }}>{p.pid}</td>
                    <td>
                      <div style={{ fontWeight: 500 }}>{p.name}</div>
                      <div className="font-mono text-dim" style={{ fontSize: 11, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.path}</div>
                    </td>
                    <td className="text-dim">{p.parent_name || '-'}</td>
                    <td style={{ color: p.cpu_percent > 50 ? 'var(--orange)' : 'inherit' }}>{p.cpu_percent?.toFixed(1)}%</td>
                    <td>{p.memory_mb?.toFixed(0)} MB</td>
                    <td className="text-dim">{p.username?.split('\\').pop()}</td>
                    <td><span style={{ fontSize: 11, color: 'var(--text-dim)' }}>{p.status}</span></td>
                    <td><Badge sev={p.risk_level} /></td>
                    <td>
                      {p.is_signed
                        ? <CheckCircle size={14} style={{ color: 'var(--green)' }} />
                        : <XCircle size={14} style={{ color: 'var(--red)' }} />}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && <Empty msg="No processes match filter" />}
          </div>
        )}
      </div>
    </div>
  )
}

// ── NETWORK ───────────────────────────────────────────────
function Network() {
  const { data: conns, loading } = useApi('/api/network', 15000)
  const { data: stats } = useApi('/api/network/stats')
  const [filter, setFilter] = useState('')

  const filtered = (conns || []).filter(c => {
    const q = filter.toLowerCase()
    return !q || c.remote_address?.includes(q) || c.process_name?.toLowerCase().includes(q) || String(c.remote_port).includes(q)
  })

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Network Monitor</h2>
        <input className="search-box" placeholder="Search IP, process, port…" value={filter} onChange={e => setFilter(e.target.value)} />
      </div>

      {stats && (
        <div className="grid-4 mb-20">
          {[
            { label: 'Total', val: stats.total, color: 'var(--accent)' },
            { label: 'Established', val: stats.established, color: 'var(--green)' },
            { label: 'Listening', val: stats.listening, color: 'var(--text-mid)' },
            { label: 'Suspicious', val: stats.suspicious, color: 'var(--red)' },
          ].map((s, i) => (
            <div className="card stat-card" key={i}><div className="stat-label">{s.label}</div><div className="stat-value" style={{ color: s.color }}>{s.val ?? 0}</div></div>
          ))}
        </div>
      )}

      <div className="card">
        {loading ? <Loading /> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>Process</th><th>Local</th><th>Remote IP</th><th>Port</th><th>Proto</th><th>State</th><th>Flag</th></tr>
              </thead>
              <tbody>
                {filtered.slice(0, 300).map((c, i) => (
                  <tr key={i} style={c.is_suspicious ? { background: 'rgba(239,68,68,0.05)' } : {}}>
                    <td>
                      <div style={{ fontWeight: 500 }}>{c.process_name || '-'}</div>
                      <div className="text-dim font-mono">{c.pid ? `PID: ${c.pid}` : ''}</div>
                    </td>
                    <td className="font-mono">{c.local_address}:{c.local_port}</td>
                    <td className="font-mono" style={{ color: c.remote_address ? 'var(--text)' : 'var(--text-dim)' }}>{c.remote_address || '—'}</td>
                    <td className="font-mono">{c.remote_port || '—'}</td>
                    <td><span className="badge badge-info">{c.protocol}</span></td>
                    <td><span style={{ fontSize: 11, color: c.state === 'ESTABLISHED' ? 'var(--green)' : 'var(--text-dim)' }}>{c.state}</span></td>
                    <td>
                      {c.is_suspicious === 1 && <span className="badge badge-critical">⚠ SUSPICIOUS</span>}
                      {c.is_known_bad === 1 && <span className="badge badge-critical">☠ KNOWN BAD</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && <Empty msg="No connections match filter" />}
          </div>
        )}
      </div>
    </div>
  )
}

// ── USB ───────────────────────────────────────────────────
function UsbMonitor() {
  const { data: usbs, loading, refetch } = useApi('/api/usb', 15000)

  async function authorize(serial) {
    await fetch(`/api/usb/${encodeURIComponent(serial)}/authorize`, { method: 'POST' })
    refetch()
  }

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">USB Security Monitor</h2>
      </div>
      {loading ? <Loading /> : (!usbs || usbs.length === 0)
        ? <div className="card"><Empty msg="No USB devices detected" /></div>
        : usbs.map((u, i) => (
          <div className="usb-card" key={i} style={{ background: u.is_authorized ? 'var(--bg-card)' : 'rgba(239,68,68,0.04)', border: `1px solid ${u.is_authorized ? 'var(--border)' : 'rgba(239,68,68,0.3)'}`, borderRadius: 10, marginBottom: 12 }}>
            <div className="usb-icon"><Usb size={20} style={{ color: u.is_authorized ? 'var(--accent)' : 'var(--red)' }} /></div>
            <div style={{ flex: 1 }}>
              <div className="flex-center gap-8" style={{ marginBottom: 4 }}>
                <span style={{ fontWeight: 600 }}>{u.product || u.vendor}</span>
                {u.is_authorized
                  ? <span className="badge badge-enabled">✓ Authorized</span>
                  : <span className="badge badge-critical">⚠ Unauthorized</span>}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>
                Vendor: {u.vendor} • S/N: {u.serial_number} • Size: {u.size_gb}GB
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 2 }}>
                First seen: {formatTime(u.first_seen)} • Last seen: {formatTime(u.last_seen)}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {!u.is_authorized && (
                <button className="btn btn-success" onClick={() => authorize(u.serial_number)}>
                  <CheckCircle size={12} /> Authorize
                </button>
              )}
            </div>
          </div>
        ))
      }
    </div>
  )
}

// ── STARTUP ───────────────────────────────────────────────
function Startup() {
  const { data, loading } = useApi('/api/startup', 30000)

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Startup & Persistence Monitor</h2>
      </div>
      <div className="card">
        {loading ? <Loading /> : (!data || data.length === 0)
          ? <Empty msg="No startup entries found" />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Name</th><th>Type</th><th>Path / Command</th><th>Status</th></tr></thead>
                <tbody>
                  {data.map((s, i) => (
                    <tr key={i} style={s.is_suspicious ? { background: 'rgba(239,68,68,0.04)' } : {}}>
                      <td style={{ fontWeight: 500 }}>{s.name}</td>
                      <td><span className="badge badge-info">{s.type}</span></td>
                      <td>
                        <div className="font-mono text-dim" style={{ maxWidth: 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {s.command || s.path || '-'}
                        </div>
                      </td>
                      <td>
                        {s.is_suspicious
                          ? <span className="badge badge-critical">⚠ SUSPICIOUS</span>
                          : <span className="badge badge-enabled">Clean</span>}
                        {s.is_new === 1 && <span className="badge badge-high" style={{ marginLeft: 4 }}>NEW</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        }
      </div>
    </div>
  )
}

// ── USERS ─────────────────────────────────────────────────
function UserActivity() {
  const { data: acts, loading } = useApi('/api/users', 30000)
  const { data: stats } = useApi('/api/users/stats')

  const eventColor = (type) => {
    if (type === 'failed_login') return 'var(--red)'
    if (type === 'rdp_login') return 'var(--orange)'
    if (type === 'new_user') return 'var(--yellow)'
    if (type === 'logout') return 'var(--text-dim)'
    return 'var(--green)'
  }

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">User Activity Monitor</h2>
      </div>
      {stats && (
        <div className="grid-4 mb-20">
          {[
            { label: 'Total Events', val: stats.total, color: 'var(--accent)' },
            { label: 'Failed Logins', val: stats.failed_logins, color: 'var(--red)' },
            { label: 'RDP Sessions', val: stats.rdp_sessions, color: 'var(--orange)' },
            { label: 'New Accounts', val: stats.new_accounts, color: 'var(--yellow)' },
          ].map((s, i) => (
            <div className="card stat-card" key={i}><div className="stat-label">{s.label}</div><div className="stat-value" style={{ color: s.color }}>{s.val ?? 0}</div></div>
          ))}
        </div>
      )}
      <div className="card">
        {loading ? <Loading /> : (!acts || acts.length === 0)
          ? <Empty msg="No user activity found (Windows Security logs required)" />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Time</th><th>User</th><th>Event</th><th>Details</th><th>IP Address</th><th>Logon Type</th><th>Result</th></tr></thead>
                <tbody>
                  {acts.map((a, i) => (
                    <tr key={i}>
                      <td className="text-dim" style={{ whiteSpace: 'nowrap', fontSize: 12 }}>{formatTime(a.collected_at)}</td>
                      <td style={{ fontWeight: 500 }}>{a.username}</td>
                      <td><span style={{ fontSize: 12, color: eventColor(a.event_type) }}>{a.event_type?.replace(/_/g, ' ').toUpperCase()}</span></td>
                      <td className="text-dim">{a.details}</td>
                      <td className="font-mono text-dim">{a.ip_address || '-'}</td>
                      <td className="text-dim">{a.logon_type || '-'}</td>
                      <td>
                        {a.success
                          ? <CheckCircle size={14} style={{ color: 'var(--green)' }} />
                          : <XCircle size={14} style={{ color: 'var(--red)' }} />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        }
      </div>
    </div>
  )
}

// ── SOFTWARE ──────────────────────────────────────────────
function Software() {
  const { data, loading } = useApi('/api/software', 60000)
  const [filter, setFilter] = useState('')

  const filtered = (data || []).filter(s => {
    const q = filter.toLowerCase()
    return !q || s.name?.toLowerCase().includes(q) || s.publisher?.toLowerCase().includes(q)
  })

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Software Inventory</h2>
        <input className="search-box" placeholder="Search software, publisher…" value={filter} onChange={e => setFilter(e.target.value)} />
      </div>
      <div className="card">
        {loading ? <Loading /> : (!data || data.length === 0)
          ? <Empty msg="No software data (Windows Registry read required)" />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Name</th><th>Version</th><th>Publisher</th><th>Install Date</th><th>Size</th><th>Status</th></tr></thead>
                <tbody>
                  {filtered.slice(0, 300).map((s, i) => (
                    <tr key={i} style={s.is_blacklisted ? { background: 'rgba(239,68,68,0.04)' } : {}}>
                      <td style={{ fontWeight: 500 }}>{s.name}</td>
                      <td className="text-dim font-mono">{s.version}</td>
                      <td className="text-dim">{s.publisher || '-'}</td>
                      <td className="text-dim">{s.install_date || '-'}</td>
                      <td className="text-dim">{s.size_mb ? `${s.size_mb} MB` : '-'}</td>
                      <td>
                        {s.is_blacklisted
                          ? <span className="badge badge-critical">☠ BLACKLISTED</span>
                          : s.is_unauthorized
                          ? <span className="badge badge-high">⚠ Unauthorized</span>
                          : <span className="badge badge-enabled">Clean</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filtered.length === 0 && <Empty msg="No software matches filter" />}
            </div>
          )
        }
      </div>
    </div>
  )
}

// ── SECURITY CONFIG ───────────────────────────────────────
function SecurityConfig() {
  const { data, loading } = useApi('/api/security-config', 60000)

  const getIcon = (status) => {
    if (status === 'enabled') return <CheckCircle size={16} style={{ color: 'var(--green)' }} />
    if (status === 'disabled') return <XCircle size={16} style={{ color: 'var(--red)' }} />
    return <AlertTriangle size={16} style={{ color: 'var(--yellow)' }} />
  }

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Security Configuration</h2>
      </div>
      <div className="card">
        {loading ? <Loading /> : (!data || data.length === 0)
          ? <Empty msg="No security config data (Windows only)" />
          : data.map((cfg, i) => (
            <div className="compliance-item" key={i}>
              <div className="flex-center gap-12">
                {getIcon(cfg.status)}
                <div>
                  <div style={{ fontWeight: 600 }}>{cfg.item}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{cfg.value}</div>
                </div>
              </div>
              <div className="flex-center gap-8">
                <Badge sev={cfg.status === 'enabled' ? 'enabled' : cfg.status === 'disabled' ? 'disabled' : 'unknown'} />
                <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>{formatTime(cfg.last_checked)}</span>
              </div>
            </div>
          ))
        }
      </div>
    </div>
  )
}

// ── FILE INTEGRITY ────────────────────────────────────────
function FileIntegrity() {
  const { data, loading } = useApi('/api/file-integrity', 30000)

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">File Integrity Monitor</h2>
      </div>
      <div className="card">
        {loading ? <Loading /> : (!data || data.length === 0)
          ? <Empty msg="No file changes detected — system files intact" />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>File Path</th><th>Event</th><th>Old Hash</th><th>New Hash</th><th>Size</th><th>Risk</th><th>Detected</th></tr></thead>
                <tbody>
                  {data.map((f, i) => (
                    <tr key={i} style={f.is_suspicious ? { background: 'rgba(239,68,68,0.04)' } : {}}>
                      <td className="font-mono" style={{ maxWidth: 250, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.path}</td>
                      <td><span className="badge badge-info">{f.event_type}</span></td>
                      <td className="font-mono text-dim" style={{ fontSize: 10 }}>{f.hash_before?.slice(0, 12)}…</td>
                      <td className="font-mono text-dim" style={{ fontSize: 10 }}>{f.hash_after?.slice(0, 12)}…</td>
                      <td className="text-dim">{f.size_bytes ? `${Math.round(f.size_bytes/1024)}KB` : '-'}</td>
                      <td>{f.is_suspicious ? <span className="badge badge-critical">SUSPICIOUS</span> : <span className="badge badge-low">Normal</span>}</td>
                      <td className="text-dim" style={{ fontSize: 11 }}>{formatTime(f.detected_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        }
      </div>
    </div>
  )
}

// ── BROWSER ───────────────────────────────────────────────
function BrowserMonitor() {
  const { data, loading } = useApi('/api/browser', 60000)

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Browser Extension Monitor</h2>
      </div>
      <div className="card">
        {loading ? <Loading /> : (!data || data.length === 0)
          ? <Empty msg="No browser extensions found (Chrome/Firefox profiles required)" />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Browser</th><th>Extension Name</th><th>Extension ID</th><th>Version</th><th>Status</th></tr></thead>
                <tbody>
                  {data.map((e, i) => (
                    <tr key={i}>
                      <td><span className="badge badge-info">{e.browser}</span></td>
                      <td style={{ fontWeight: 500 }}>{e.extension_name}</td>
                      <td className="font-mono text-dim" style={{ fontSize: 11 }}>{e.extension_id?.slice(0, 20)}…</td>
                      <td className="text-dim">{e.version}</td>
                      <td>
                        {e.is_suspicious
                          ? <span className="badge badge-critical">⚠ SUSPICIOUS</span>
                          : e.enabled
                          ? <span className="badge badge-enabled">Enabled</span>
                          : <span className="badge badge-unknown">Disabled</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        }
      </div>
    </div>
  )
}

// ── THREAT HUNTING ────────────────────────────────────────
function ThreatHunting() {
  const { data, loading, refetch } = useApi('/api/threats', 30000)

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Threat Hunting Engine</h2>
        <button className="btn btn-primary" onClick={refetch}><RefreshCw size={14} /> Run Hunt</button>
      </div>

      {loading ? <Loading /> : (!data?.findings || data.findings.length === 0)
        ? (
          <div className="card">
            <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--green)' }}>
              <Shield size={48} style={{ marginBottom: 12, opacity: 0.7 }} />
              <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>No Threats Detected</div>
              <div className="text-dim">System appears clean. Running continuous hunt…</div>
            </div>
          </div>
        )
        : (
          <>
            <div className="card mb-16" style={{ padding: '12px 20px', background: 'rgba(239,68,68,0.08)', borderColor: 'rgba(239,68,68,0.3)' }}>
              <span style={{ color: 'var(--red)', fontWeight: 600 }}>⚠ {data.total} threat indicator(s) detected</span>
            </div>
            {data.findings.map((f, i) => (
              <div className={`threat-card ${f.severity}`} key={i}>
                <div className="flex-between" style={{ marginBottom: 8 }}>
                  <div className="flex-center gap-8">
                    <Badge sev={f.severity} />
                    <span style={{ fontWeight: 600, fontSize: 14 }}>{f.type}</span>
                  </div>
                  <span style={{ fontSize: 11, color: 'var(--text-dim)' }}>{formatTime(f.detected_at)}</span>
                </div>
                <div style={{ fontSize: 13, marginBottom: 6 }}>{f.description}</div>
                {f.mitre && (
                  <div style={{ fontSize: 11, color: 'var(--accent)', background: 'rgba(0,212,255,0.08)', padding: '3px 8px', borderRadius: 4, display: 'inline-block' }}>
                    MITRE: {f.mitre}
                  </div>
                )}
                {f.cmdline && (
                  <div className="font-mono" style={{ marginTop: 8, padding: '6px 10px', background: 'rgba(0,0,0,0.3)', borderRadius: 4, fontSize: 11, color: 'var(--text-dim)', wordBreak: 'break-all' }}>
                    {f.cmdline.slice(0, 300)}
                  </div>
                )}
              </div>
            ))}
          </>
        )
      }
    </div>
  )
}

// ── AI RISK ───────────────────────────────────────────────
function AIRisk() {
  const { data, loading, refetch } = useApi('/api/risk', 30000)

  if (loading) return <div className="page"><Loading /></div>
  if (!data) return <div className="page"><Empty /></div>

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">AI Risk Engine</h2>
        <button className="btn btn-primary" onClick={refetch}><RefreshCw size={14} /> Re-Analyze</button>
      </div>

      {/* Overall risk */}
      <div className="card mb-20">
        <div className="grid-2">
          <div className="flex-center gap-24">
            <RiskGauge score={data.overall_risk} size={160} />
            <div>
              <div style={{ fontSize: 28, fontWeight: 700, color: riskColor(data.overall_risk), marginBottom: 4 }}>
                {riskLabel(data.overall_risk)} RISK
              </div>
              <div style={{ fontSize: 14, color: 'var(--text-dim)', marginBottom: 12 }}>Overall endpoint risk score</div>
              <div>
                <div className="flex-center gap-8" style={{ marginBottom: 4 }}>
                  <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>Attack Probability:</span>
                  <span style={{ fontWeight: 700, color: riskColor(data.attack_probability) }}>{data.attack_probability}%</span>
                </div>
                <div className="flex-center gap-8">
                  <span style={{ fontSize: 12, color: 'var(--text-dim)' }}>Compromise Risk:</span>
                  <span style={{ fontWeight: 700, color: riskColor(data.compromise_probability) }}>{data.compromise_probability}%</span>
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="card-title">Risk Breakdown</div>
            {[
              { label: 'Process Risk', val: data.process_risk },
              { label: 'Network Risk', val: data.network_risk },
              { label: 'User Risk', val: data.user_risk },
              { label: 'Persistence Risk', val: data.persistence_risk },
              { label: 'USB Risk', val: data.usb_risk },
              { label: 'Software Risk', val: data.software_risk },
              { label: 'Config Risk', val: data.config_risk },
            ].map((r, i) => (
              <div className="risk-row" key={i}>
                <span className="risk-label">{r.label}</span>
                <div className="risk-bar"><ProgressBar value={r.val} /></div>
                <span className="risk-value" style={{ color: riskColor(r.val) }}>{r.val}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid-2 mb-20">
        {/* Threat classification */}
        <div className="card">
          <div className="card-title">Threat Classification</div>
          {data.threat_classification?.map((t, i) => (
            <div key={i} style={{ marginBottom: 14 }}>
              <div className="flex-between" style={{ marginBottom: 6 }}>
                <span style={{ fontSize: 13 }}>{t.type}</span>
                <span style={{ fontWeight: 700, color: riskColor(t.probability) }}>{t.probability}%</span>
              </div>
              <ProgressBar value={t.probability} color={riskColor(t.probability)} />
            </div>
          ))}
        </div>

        {/* Recommendations */}
        <div className="card">
          <div className="card-title">Recommendations</div>
          {(!data.recommendations || data.recommendations.length === 0)
            ? <div className="flex-center gap-8" style={{ color: 'var(--green)', padding: '20px 0' }}><CheckCircle size={16} /> System is well-configured!</div>
            : data.recommendations.map((r, i) => (
              <div key={i} style={{ padding: '10px 0', borderBottom: '1px solid rgba(30,45,74,0.5)' }}>
                <div className="flex-center gap-8" style={{ marginBottom: 4 }}>
                  <Zap size={13} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                  <span style={{ fontWeight: 600, fontSize: 13 }}>{r.issue}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-dim)', paddingLeft: 21 }}>{r.action}</div>
              </div>
            ))
          }
        </div>
      </div>

      {/* Risk reasons */}
      {data.risk_reasons?.length > 0 && (
        <div className="card">
          <div className="card-title">Risk Factors ({data.risk_reasons.length})</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {data.risk_reasons.map((r, i) => (
              <span key={i} style={{ background: 'rgba(239,68,68,0.1)', color: 'var(--red-bright)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 6, padding: '4px 10px', fontSize: 12 }}>{r}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── ALERTS ───────────────────────────────────────────────
function Alerts() {
  const { data, loading, refetch } = useApi('/api/alerts?resolved=0', 15000)
  const { data: stats } = useApi('/api/alerts/stats')
  const [filter, setFilter] = useState('all')

  async function resolve(id) {
    await fetch(`/api/alerts/${id}/resolve`, { method: 'POST' })
    refetch()
  }

  const filtered = (data || []).filter(a => filter === 'all' || a.severity === filter)

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Alert Center</h2>
        <div className="flex-center gap-8">
          {['all','critical','high','medium','low'].map(f => (
            <button key={f} className={`btn ${filter === f ? 'btn-primary' : 'btn-outline'}`} style={{ fontSize: 12 }} onClick={() => setFilter(f)}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
              {stats && f !== 'all' && stats[f] > 0 && <span className="nav-badge" style={{ marginLeft: 4, background: 'transparent', color: 'inherit' }}>{stats[f]}</span>}
            </button>
          ))}
        </div>
      </div>

      {stats && (
        <div className="grid-4 mb-20">
          {[
            { label: 'Open Alerts', val: stats.total, color: 'var(--accent)' },
            { label: 'Critical', val: stats.critical, color: 'var(--red)' },
            { label: 'High', val: stats.high, color: 'var(--orange)' },
            { label: 'Medium', val: stats.medium, color: 'var(--yellow)' },
          ].map((s, i) => (
            <div className="card stat-card" key={i}><div className="stat-label">{s.label}</div><div className="stat-value" style={{ color: s.color }}>{s.val ?? 0}</div></div>
          ))}
        </div>
      )}

      <div className="card">
        {loading ? <Loading /> : filtered.length === 0
          ? <Empty msg="No open alerts" />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Severity</th><th>Title</th><th>Description</th><th>Module</th><th>Time</th><th>Action</th></tr></thead>
                <tbody>
                  {filtered.map((a, i) => (
                    <tr key={i}>
                      <td><Badge sev={a.severity} /></td>
                      <td style={{ fontWeight: 600, whiteSpace: 'nowrap' }}>{a.title}</td>
                      <td style={{ fontSize: 12, color: 'var(--text-dim)', maxWidth: 300 }}>{a.description?.slice(0, 100)}</td>
                      <td><span className="badge badge-info">{a.module}</span></td>
                      <td className="text-dim" style={{ fontSize: 12, whiteSpace: 'nowrap' }}>{formatTime(a.created_at)}</td>
                      <td>
                        <button className="btn btn-outline" style={{ fontSize: 11, padding: '4px 10px' }} onClick={() => resolve(a.id)}>
                          <CheckCircle size={12} /> Resolve
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        }
      </div>
    </div>
  )
}

// ── TIMELINE ──────────────────────────────────────────────
function Timeline() {
  const { data, loading } = useApi('/api/timeline', 15000)

  const dotColor = (sev) => {
    if (sev === 'critical') return '#ef4444'
    if (sev === 'high') return '#f97316'
    if (sev === 'medium') return '#f59e0b'
    if (sev === 'threat') return '#ef4444'
    return '#10b981'
  }

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">EndSight Timeline</h2>
      </div>
      {loading ? <Loading /> : (!data || data.length === 0)
        ? <Empty msg="No timeline events yet — collection running…" />
        : (
          <div className="card">
            <div className="timeline">
              {data.map((e, i) => (
                <div className="timeline-item" key={i}>
                  <div className="timeline-dot" style={{ background: dotColor(e.severity) }} />
                  <div className="timeline-content">
                    <div className="flex-between">
                      <div className="timeline-time">{formatTime(e.created_at)}</div>
                      <div className="flex-center gap-8">
                        <span className="badge badge-info" style={{ fontSize: 10 }}>{e.module}</span>
                        <Badge sev={e.severity} />
                      </div>
                    </div>
                    <div className="timeline-desc">{e.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )
      }
    </div>
  )
}

// ── FORENSICS ─────────────────────────────────────────────
function Forensics() {
  const { data, loading } = useApi('/api/forensics', 60000)
  const [tab, setTab] = useState('process')

  const tabs = [
    { id: 'process', label: 'Process History' },
    { id: 'login', label: 'Login History' },
    { id: 'usb', label: 'USB History' },
    { id: 'software', label: 'Software History' },
  ]

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Digital Forensics</h2>
      </div>
      <div className="flex-center gap-8 mb-20">
        {tabs.map(t => (
          <button key={t.id} className={`btn ${tab === t.id ? 'btn-primary' : 'btn-outline'}`} onClick={() => setTab(t.id)}>{t.label}</button>
        ))}
      </div>
      <div className="card">
        {loading ? <Loading /> : (
          <div className="table-wrap">
            {tab === 'process' && (
              <table>
                <thead><tr><th>Process</th><th>Path</th><th>Risk</th><th>Time</th></tr></thead>
                <tbody>
                  {(data?.process_history || []).map((p, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 500 }}>{p.name}</td>
                      <td className="font-mono text-dim" style={{ fontSize: 11, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.path}</td>
                      <td><Badge sev={p.risk_level} /></td>
                      <td className="text-dim" style={{ fontSize: 12 }}>{formatTime(p.collected_at)}</td>
                    </tr>
                  ))}
                  {(!data?.process_history || data.process_history.length === 0) && <tr><td colSpan={4}><Empty msg="No process history" /></td></tr>}
                </tbody>
              </table>
            )}
            {tab === 'login' && (
              <table>
                <thead><tr><th>User</th><th>Event</th><th>IP</th><th>Result</th><th>Time</th></tr></thead>
                <tbody>
                  {(data?.login_history || []).map((l, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 500 }}>{l.username}</td>
                      <td>{l.event_type?.replace(/_/g,' ').toUpperCase()}</td>
                      <td className="font-mono text-dim">{l.ip_address || '-'}</td>
                      <td>{l.success ? <CheckCircle size={14} style={{ color: 'var(--green)' }} /> : <XCircle size={14} style={{ color: 'var(--red)' }} />}</td>
                      <td className="text-dim" style={{ fontSize: 12 }}>{formatTime(l.collected_at)}</td>
                    </tr>
                  ))}
                  {(!data?.login_history || data.login_history.length === 0) && <tr><td colSpan={5}><Empty msg="No login history" /></td></tr>}
                </tbody>
              </table>
            )}
            {tab === 'usb' && (
              <table>
                <thead><tr><th>Product</th><th>Vendor</th><th>Serial Number</th><th>Size</th><th>Auth</th><th>Last Seen</th></tr></thead>
                <tbody>
                  {(data?.usb_history || []).map((u, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 500 }}>{u.product}</td>
                      <td className="text-dim">{u.vendor}</td>
                      <td className="font-mono text-dim">{u.serial_number}</td>
                      <td className="text-dim">{u.size_gb}GB</td>
                      <td>{u.is_authorized ? <span className="badge badge-enabled">Auth</span> : <span className="badge badge-critical">Unknown</span>}</td>
                      <td className="text-dim" style={{ fontSize: 12 }}>{formatTime(u.last_seen)}</td>
                    </tr>
                  ))}
                  {(!data?.usb_history || data.usb_history.length === 0) && <tr><td colSpan={6}><Empty msg="No USB history" /></td></tr>}
                </tbody>
              </table>
            )}
            {tab === 'software' && (
              <table>
                <thead><tr><th>Software</th><th>Version</th><th>Publisher</th><th>Install Date</th></tr></thead>
                <tbody>
                  {(data?.software_history || []).map((s, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 500 }}>{s.name}</td>
                      <td className="font-mono text-dim">{s.version}</td>
                      <td className="text-dim">{s.publisher}</td>
                      <td className="text-dim">{s.install_date || '-'}</td>
                    </tr>
                  ))}
                  {(!data?.software_history || data.software_history.length === 0) && <tr><td colSpan={4}><Empty msg="No software history" /></td></tr>}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// ── SETTINGS ──────────────────────────────────────────────
function SettingsPage() {
  const { data, loading } = useApi('/api/settings')
  const [settings, setSettings] = useState({})
  const [saved, setSaved] = useState(false)

  useEffect(() => { if (data) setSettings(data) }, [data])

  async function save() {
    await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(settings) })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const fields = [
    { key: 'collection_interval_seconds', label: 'Collection Interval (seconds)', type: 'number', desc: 'How often to collect endpoint data (min: 30)' },
    { key: 'alert_email', label: 'Alert Email', type: 'text', desc: 'Email address for critical alert notifications' },
    { key: 'webhook_url', label: 'Webhook URL', type: 'text', desc: 'HTTP endpoint for alert webhook notifications' },
    { key: 'monitor_paths', label: 'Monitor Paths', type: 'text', desc: 'Comma-separated paths for file integrity monitoring' },
    { key: 'threat_hunting_enabled', label: 'Threat Hunting', type: 'select', options: [['1','Enabled'],['0','Disabled']], desc: 'Enable automatic threat hunting' },
    { key: 'usb_block_unauthorized', label: 'Block Unauthorized USB', type: 'select', options: [['0','Monitor Only'],['1','Block & Alert']], desc: 'Action for unauthorized USB devices' },
  ]

  return (
    <div className="page">
      <div className="section-header mb-20">
        <h2 className="section-title">Settings</h2>
        <button className="btn btn-primary" onClick={save}>{saved ? '✓ Saved!' : 'Save Settings'}</button>
      </div>
      <div className="card">
        {loading ? <Loading /> : fields.map((f, i) => (
          <div key={i} style={{ padding: '16px 0', borderBottom: '1px solid rgba(30,45,74,0.5)' }}>
            <div className="flex-between">
              <div>
                <div style={{ fontWeight: 600, marginBottom: 2 }}>{f.label}</div>
                <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{f.desc}</div>
              </div>
              {f.type === 'select' ? (
                <select value={settings[f.key] || ''} onChange={e => setSettings({ ...settings, [f.key]: e.target.value })}
                  style={{ background: 'var(--bg-hover)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: 6, padding: '7px 12px', fontSize: 13 }}>
                  {f.options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              ) : (
                <input type={f.type} value={settings[f.key] || ''} onChange={e => setSettings({ ...settings, [f.key]: e.target.value })}
                  style={{ background: 'var(--bg-hover)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: 6, padding: '7px 12px', fontSize: 13, width: 300 }} />
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <div className="card-title">System Info</div>
        <div style={{ fontSize: 13, color: 'var(--text-dim)', lineHeight: 2 }}>
          <div>Version: <span className="text-accent">EndSight-OS v1.0.0</span></div>
          <div>Backend: <span className="text-accent">http://localhost:8000</span></div>
          <div>Database: <span className="text-accent">SQLite (endsight.db)</span></div>
          <div>Collection: <span className="text-accent">psutil + WMI + Windows Registry</span></div>
          <div>AI Engine: <span className="text-accent">Multi-factor weighted risk scoring</span></div>
        </div>
      </div>
    </div>
  )
}

// ── MAIN APP ──────────────────────────────────────────────
const NAV = [
  { id: 'dashboard',    label: 'Dashboard',      icon: <LayoutDashboard size={16} />, section: 'OVERVIEW' },
  { id: 'alerts',       label: 'Alert Center',   icon: <Bell size={16} />,            section: null, badge: true },
  { id: 'threats',      label: 'Threat Hunting', icon: <Target size={16} />,          section: null },
  { id: 'risk',         label: 'AI Risk Engine', icon: <TrendingUp size={16} />,      section: null },
  { id: 'processes',    label: 'Processes',      icon: <Activity size={16} />,        section: 'MONITORING' },
  { id: 'network',      label: 'Network',        icon: <Wifi size={16} />,            section: null },
  { id: 'usb',          label: 'USB Security',   icon: <Usb size={16} />,             section: null },
  { id: 'startup',      label: 'Persistence',    icon: <Play size={16} />,            section: null },
  { id: 'users',        label: 'User Activity',  icon: <Users size={16} />,           section: null },
  { id: 'software',     label: 'Software',       icon: <Package size={16} />,         section: 'SECURITY' },
  { id: 'secconfig',    label: 'Security Config',icon: <Lock size={16} />,            section: null },
  { id: 'fileintegrity',label: 'File Integrity', icon: <FileSearch size={16} />,      section: null },
  { id: 'browser',      label: 'Browser',        icon: <Globe size={16} />,           section: null },
  { id: 'timeline',     label: 'Timeline',       icon: <Clock size={16} />,           section: 'FORENSICS' },
  { id: 'forensics',    label: 'Digital Forensics',icon: <Eye size={16} />,           section: null },
  { id: 'settings',     label: 'Settings',       icon: <Settings size={16} />,        section: 'SYSTEM' },
]

export default function App() {
  const [page, setPage] = useState('dashboard')
  const { data: alertStats } = useApi('/api/alerts/stats', 30000)

  const pages = {
    dashboard:     <Dashboard onAlert={() => setPage('alerts')} />,
    processes:     <Processes />,
    network:       <Network />,
    usb:           <UsbMonitor />,
    startup:       <Startup />,
    users:         <UserActivity />,
    software:      <Software />,
    secconfig:     <SecurityConfig />,
    fileintegrity: <FileIntegrity />,
    browser:       <BrowserMonitor />,
    threats:       <ThreatHunting />,
    risk:          <AIRisk />,
    alerts:        <Alerts />,
    timeline:      <Timeline />,
    forensics:     <Forensics />,
    settings:      <SettingsPage />,
  }

  const currentNav = NAV.find(n => n.id === page)

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <h1>🛡 EndSight-OS</h1>
          <p>Endpoint Security Platform</p>
        </div>
        <nav className="sidebar-nav">
          {NAV.map((item, i) => (
            <div key={item.id}>
              {item.section && <div className="nav-section">{item.section}</div>}
              <div className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}>
                {item.icon}
                <span>{item.label}</span>
                {item.badge && alertStats?.critical > 0 && (
                  <span className="nav-badge">{alertStats.critical}</span>
                )}
              </div>
            </div>
          ))}
        </nav>
        <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text-dim)' }}>
          <div className="flex-center gap-6">
            <div className="status-dot" />
            <span>Live Monitoring Active</span>
          </div>
        </div>
      </aside>

      <div className="main-content">
        <div className="topbar">
          <div className="flex-center gap-8">
            {currentNav?.icon && <span style={{ color: 'var(--accent)' }}>{currentNav.icon}</span>}
            <span className="topbar-title">{currentNav?.label}</span>
          </div>
          <div className="topbar-right">
            <div className="flex-center gap-6 text-dim" style={{ fontSize: 12 }}>
              <div className="status-dot" />
              <span>Endpoint Connected</span>
            </div>
          </div>
        </div>

        <div style={{ flex: 1 }}>
          {pages[page]}
        </div>
      </div>
    </div>
  )
}
